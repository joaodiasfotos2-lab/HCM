// Gera os 55 clubes e plantéis da 3ª Divisão (nomes reais dos clubes, jogadores inventados),
// reaproveitando a mesma lógica de atributos/potencial já usada no motor do jogo, calibrada
// para o nível mais fraco (a divisão mais baixa implementada).
const fs = require("fs");

const PT_FIRST_NAMES = ["João","Miguel","Pedro","Rui","André","Tiago","Bruno","Carlos","Diogo","Ricardo","Nuno","Hugo","Filipe","Gonçalo","Vasco","Rafael","Francisco","Tomás","Duarte","Martim","Afonso","Guilherme","Luís","José","António","Manuel","Paulo","Fernando","Sérgio","Vítor","Alexandre","Daniel","Marco","Renato","Fábio","Ivo","Pedro Miguel","Xavier","Simão","Leonardo"];
const PT_LAST_NAMES = ["Silva","Santos","Ferreira","Pereira","Oliveira","Costa","Rodrigues","Martins","Jesus","Sousa","Fernandes","Gonçalves","Gomes","Lopes","Marques","Alves","Almeida","Ribeiro","Pinto","Carvalho","Teixeira","Moreira","Correia","Mendes","Nunes","Soares","Vieira","Monteiro","Cardoso","Rocha","Neves","Coelho","Cruz","Cunha","Pires","Ramos","Reis","Simões","Antunes","Matos","Machado","Tavares","Melo","Barros","Batista"];

function rnd(min,max){ return Math.floor(Math.random()*(max-min+1))+min; }
function pick(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
function clampAttr(v){ return Math.max(1, Math.min(20, Math.round(v))); }

function randomName(){
  const first = pick(PT_FIRST_NAMES);
  let last1 = pick(PT_LAST_NAMES);
  if(Math.random()<0.4){
    let last2 = pick(PT_LAST_NAMES);
    let guard=0; while(last2===last1 && guard<5){ last2=pick(PT_LAST_NAMES); guard++; }
    return `${first} ${last1} ${last2}`;
  }
  return `${first} ${last1}`;
}

function slug(name){
  return name.toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g,"")
    .replace(/["'`´]/g,"")
    .replace(/[^a-z0-9]+/g,"-")
    .replace(/^-+|-+$/g,"");
}

// Nível mais fraco implementado: base de atributos bastante abaixo da 2ª Divisão (que já é
// a divisão mais fraca de antes), com variação individual ampla — plantéis desiguais, alguns
// jogadores claramente acima da média da própria divisão, tal como no futebol/hóquei amador real.
function genOutfield(clubName, num){
  const name = randomName();
  const id = `${slug(clubName)}-${slug(name)}-${num}`;
  const linha = Math.random()<0.5 ? "Avancado" : "DefesaMedio";
  const age = rnd(18,35);
  const base = clampAttr(rnd(3,7));
  const attrs = {
    habilidade: clampAttr(base+rnd(-2,2)),
    drible: clampAttr(base+rnd(-2,2)),
    criatividade: clampAttr(base+rnd(-2,2)),
    finalizacao: clampAttr(base+rnd(-3,3)),
    bolasParadas: clampAttr(base+rnd(-3,3)),
    meiaDistancia: clampAttr(base+rnd(-3,3)),
    posicionamento: clampAttr(base+rnd(-2,2)),
    desarme: clampAttr(base+rnd(-3,3)),
    forca: clampAttr(base+rnd(-2,2)),
    velocidade: clampAttr(base+rnd(-3,3)),
    aceleracao: clampAttr(base+rnd(-3,3)),
    agressividade: clampAttr(rnd(4,16)),
    determinacao: clampAttr(rnd(5,16)),
    lideranca: clampAttr(rnd(4,15)),
    resistencia: clampAttr(base+rnd(-2,2)),
  };
  const potencial = clampAttr(base + (age<=21?rnd(1,5):rnd(-1,2)));
  const year = 2026 - age, month = rnd(0,11), day = rnd(1,28);
  const dataNascimento = new Date(Date.UTC(year,month,day)).toISOString().slice(0,10);
  return { id, num, name, pos:"J", linha, idade:age, age, dataNascimento, nacionalidade:"Portugal",
    attrs, potencial, temperamento: pick(["Profissional","Equilibrado","Impulsivo","Calmo"]),
    historico:[{epoca:"2026/27",clube:clubName,jogos:0,golos:0,assistencias:0}], titulos:[],
    internacionalizacoes:0, golosInternacional:0 };
}
function genGoalkeeper(clubName, num){
  const name = randomName();
  const id = `${slug(clubName)}-${slug(name)}-${num}`;
  const age = rnd(18,35);
  const base = clampAttr(rnd(3,7));
  const attrs = {
    reflexos: clampAttr(base+rnd(-2,2)),
    umParaUm: clampAttr(base+rnd(-2,2)),
    agilidade: clampAttr(base+rnd(-2,2)),
    concentracao: clampAttr(base+rnd(-2,2)),
    meiaDistancia: clampAttr(base+rnd(-3,3)),
    forca: clampAttr(base+rnd(-2,2)),
    agressividade: clampAttr(rnd(4,14)),
    determinacao: clampAttr(rnd(5,16)),
    lideranca: clampAttr(rnd(4,15)),
    resistencia: clampAttr(base+rnd(-2,2)),
  };
  const potencial = clampAttr(base + (age<=21?rnd(1,4):rnd(-1,2)));
  const year = 2026 - age, month = rnd(0,11), day = rnd(1,28);
  const dataNascimento = new Date(Date.UTC(year,month,day)).toISOString().slice(0,10);
  return { id, num, name, pos:"GR", linha:null, idade:age, age, dataNascimento, nacionalidade:"Portugal",
    attrs, potencial, temperamento: pick(["Profissional","Equilibrado","Impulsivo","Calmo"]),
    historico:[{epoca:"2026/27",clube:clubName,jogos:0,golos:0,assistencias:0}], titulos:[],
    internacionalizacoes:0, golosInternacional:0 };
}
function genRoster(clubName){
  const players = [];
  let num=1;
  players.push(genGoalkeeper(clubName,num++));
  players.push(genGoalkeeper(clubName,num++));
  for(let i=0;i<5;i++) players.push(genOutfield(clubName,num++));
  for(let i=0;i<5;i++) players.push(genOutfield(clubName,num++));
  return players;
}

const COLORS = ["#1B4D89","#7A1F1F","#1F6B3A","#8A6D1F","#4A2E7A","#1F7A7A","#7A1F5C","#3A3A3A","#8A4A1F","#1F3A7A"];
function colorFor(i){ return COLORS[i%COLORS.length]; }

const ZONES = {
  "norte-a": ["Riba D'Ave HC \"B\"","GDC Fânzeres","USC Paredes","HC Fão","Académico FC","HC Braga \"B\"","VizelaSkating","HC Marco","HC Penafiel","HC Maia","Valença HC","J. Pacense \"B\"","CAR Taipense","AD Barcelos"],
  "norte-b": ["AD Sanjoanense B","ACD Gulpilhares","ACDCP Vila Boa Bispo","CD Cucujães","Escola Livre A","CH Carvalhos \"B\"","CP Sobreira","AA Espinho \"B\"","ACR Pessegueiro Vouga","CI Sagres","CENAP","HC Paço de Rei","CA Feira","HA Cambra \"B\""],
  "sul-a": ["Biblioteca IR","Juventude Ouriense","UF Entroncamento/Entrosegur","A Académica C \"B\"","HC Turquel \"B\"","GD Estreito","HC Mealhada \"B\"","CRC \"Os Águias\"","SC Torres","HC \"Os Tigres\"/Work Permit","HC Madeira","OH Sports","ACR Santa Cita"],
  "sul-b": ["J. Azeitonense","UD Vilafranquense","GDS Cascais","HC Santiago","GD Sesimbra","GCC \"Os Corujas\"","A Stuart HC Massamá","S Alenquer B \"B\"","HC Ponta Delgada","HC Vasco da Gama/J.Ascenção","AE Física D \"B\"","CD Boliqueime","CD Paço de Arcos \"B\"","HC Sintra/Planta Livre"],
};

const clubs = [];
const rosters = {};
let colorIdx = 0;
Object.entries(ZONES).forEach(([zona, names])=>{
  const regiao = zona.startsWith("norte") ? "norte" : "sul";
  names.forEach(name=>{
    const id = slug(name);
    const color = colorFor(colorIdx++);
    clubs.push({
      id, name, color, primaryColor: color, secondaryColor: "#FFFFFF", tertiaryColor: "#111111",
      tier: 4, reputacao: "Local", condicoesTreino: "Razoáveis",
      divisaoAtual: "3div", zona,
    });
    rosters[id] = genRoster(name);
  });
});

console.log(JSON.stringify({clubs, rosters}, null, 2));
