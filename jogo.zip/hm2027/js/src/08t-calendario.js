// Calendário visual, amigáveis em qualquer altura da época e quadrangulares (2026-10-12, pedido do
// utilizador: "tem de se ver tipo calendário"; "no separador calendário deve ser possível marcar
// jogos amigáveis (propor em casa ou fora) e pequenos torneios").
//
// Decisões de desenho confirmadas por ele:
//   - O amigável é proposto a um clube de IA, que responde em 1 a 3 dias (aceita consoante a
//     reputação, a deslocação, se joga em casa ou fora e se tem jogos oficiais por perto).
//   - Qualquer altura da época, em dias sem jogo oficial nos 2 dias anteriores e seguintes.
//   - Torneio = quadrangular de 2 dias (meias-finais num dia, final e 3.º/4.º no seguinte). O
//     utilizador organiza em casa (convida 3 clubes) ou pede a um clube para o receber fora.
//
// Estado global em state.calAmig (dados simples, guardados no save):
//   { v, jogos[], pedidos[], torneios[], recusas{teamId: isoData}, seq, historico[] }
//   jogos     amigáveis aceites (mesma forma dos de pré-época: id, date, home, away, oppId, casa,
//             played, cancelled, homeScore, awayScore, custo, amigavel, origem:"cal")
//   pedidos   propostas de amigável por responder / respondidas
//   torneios  { id, nome, modo:"casa"|"fora", anfitriao, data1, data2, estado, convites[],
//               participantes[], jogos[], ... }
// Todas as datas aqui são cadeias ISO (AAAA-MM-DD) e a aritmética é feita em UTC.

const CAL_RESP_MIN = 1, CAL_RESP_MAX = 3;
const CAL_FOLGA_OFICIAL = 2;        // dias sem jogo oficial antes e depois
const CAL_FOLGA_AMIGAVEL = 2;       // distância mínima entre dois jogos de preparação
const CAL_ANTECEDENCIA_AMIGAVEL = 4;
const CAL_ANTECEDENCIA_TORNEIO = 6;
const CAL_MAX_DIAS = 150;
const CAL_RECUSA_DIAS = 30;
const CAL_ACEITA_MIN = 55;
const CAL_PREMIOS = { 1: 5000, 2: 2500, 3: 1200, 4: 500 };
const CAL_DIV_FATOR = { 3: 1, 2: 0.4, 1: 0.15 };
const CAL_TORNEIO_CUSTO_CASA = 2.5;   // × custo de um amigável em casa
const CAL_TORNEIO_CUSTO_FORA = 2;     // × custo de um amigável fora

const calUI = { mes: null, sel: null, modo: "amigavel", oppId: null, casa: "1", convidados: ["", "", ""], hostId: null, erro: "", aba: "mensal" };

// ---------------------------------------------------------------- Estado e datas
function calEnsure() {
  if (!state.calAmig || typeof state.calAmig !== "object") state.calAmig = { v: 1, jogos: [], pedidos: [], torneios: [], recusas: {}, seq: 0, historico: [] };
  const c = state.calAmig;
  if (!Array.isArray(c.jogos)) c.jogos = [];
  if (!Array.isArray(c.pedidos)) c.pedidos = [];
  if (!Array.isArray(c.torneios)) c.torneios = [];
  if (!Array.isArray(c.historico)) c.historico = [];
  if (!c.recusas || typeof c.recusas !== "object") c.recusas = {};
  if (typeof c.seq !== "number") c.seq = 0;
  return c;
}
function calNovoId(prefixo) { const c = calEnsure(); c.seq += 1; return `${prefixo}-${state.season}-${c.seq}`; }
function calHoje() { return isoDate(state.currentDate); }
function calIsoAdd(iso, n) { return new Date(Date.parse(iso) + n * 86400000).toISOString().slice(0, 10); }
function calDiff(a, b) { return Math.round((Date.parse(a) - Date.parse(b)) / 86400000); }
function calPad(n) { return String(n).padStart(2, "0"); }
function calMesDe(iso) { return iso.slice(0, 7); }
function calMesAdd(mes, n) {
  const y = +mes.slice(0, 4), m = +mes.slice(5, 7) - 1 + n;
  const d = new Date(Date.UTC(y, m, 1));
  return `${d.getUTCFullYear()}-${calPad(d.getUTCMonth() + 1)}`;
}
function calMesLabel(mes) { return `${MONTHS[+mes.slice(5, 7) - 1]} ${mes.slice(0, 4)}`; }
function calDataLonga(iso) { const d = new Date(Date.parse(iso)); return `${WEEKDAYS[d.getUTCDay()]}, ${d.getUTCDate()} de ${MONTHS[d.getUTCMonth()]} de ${d.getUTCFullYear()}`; }
function calDataCurta(iso) { return `${calPad(+iso.slice(8, 10))}/${iso.slice(5, 7)}`; }
function calSigla(team) { return team ? (team.sigla || team.short || String(team.name || "?").replace(/^(HC|CP|CH|CE|FC|AD|GD|UD|SC)\s+/i, "").slice(0, 9)) : "?"; }

// Datas (ISO) dos jogos oficiais do clube do utilizador (todas as provas com data conhecida).
function calDatasOficiais() {
  const out = new Set();
  try { myFullSchedule().forEach(r => { if (r.date) out.add(isoDate(r.date)); }); } catch (e) {}
  try { preSeasonOfficialDates().forEach(d => out.add(isoDate(d))); } catch (e) {}
  return out;
}
// Jogos de preparação do utilizador (pré-época + calendário + torneios) e pedidos em espera.
function calDatasPreparacao(ignorarId) {
  const out = [];
  const ps = state.preSeason && state.preSeason.epoca === state.season ? state.preSeason : null;
  if (ps) ps.amigaveis.forEach(g => { if (!g.cancelled) out.push({ iso: isoDate(g.date), id: g.id }); });
  const c = calEnsure();
  c.jogos.forEach(g => { if (!g.cancelled) out.push({ iso: g.date, id: g.id }); });
  c.pedidos.forEach(p => { if (p.estado === "pendente" && p.tipo === "amigavel") out.push({ iso: p.date, id: p.id }); });
  (c.convites || []).forEach(cv => { if (cv.estado === "pendente") out.push({ iso: cv.date, id: cv.id }); });
  c.torneios.forEach(t => {
    if (t.estado === "cancelado" || t.estado === "concluido") return;
    out.push({ iso: t.data1, id: t.id }); out.push({ iso: t.data2, id: t.id });
  });
  return out.filter(x => x.id !== ignorarId);
}
function calDatasEstagio() {
  const ps = state.preSeason && state.preSeason.epoca === state.season ? state.preSeason : null;
  try { return ps ? preSeasonStageDates(ps) : []; } catch (e) { return []; }
}
function calUltimaData() {
  if (state.seasonOver || state.playoffActive) return null;
  const comp = state.competitions && state.competitions[state.userCompetitionId];
  const fx = comp && comp.fixtures;
  if (!fx || !fx.length) return null;
  const ultimo = fx[fx.length - 1].date;
  const lim = calIsoAdd(isoDate(ultimo), -1);
  const max = calIsoAdd(calHoje(), CAL_MAX_DIAS);
  return lim < max ? lim : max;
}
// Validade de uma data para o clube do utilizador. antecedencia: dias mínimos desde hoje.
function calDataValida(iso, opts) {
  opts = opts || {};
  const antec = opts.antecedencia != null ? opts.antecedencia : CAL_ANTECEDENCIA_AMIGAVEL;
  const hoje = calHoje();
  if (!iso || !/^\d{4}-\d{2}-\d{2}$/.test(iso)) return { ok: false, reason: "Data inválida." };
  if (iso <= hoje) return { ok: false, reason: "A data tem de ser posterior a hoje." };
  if (calDiff(iso, hoje) < antec) return { ok: false, reason: `É preciso marcar com pelo menos ${antec} dias de antecedência.` };
  const max = calUltimaData();
  if (!max) return { ok: false, reason: "Já não há jogos de preparação possíveis nesta fase da época." };
  if (iso > max) return { ok: false, reason: "Fora do período em que se pode marcar jogos de preparação." };
  if (calDatasOficiais().has(iso) || [...calDatasOficiais()].some(o => Math.abs(calDiff(o, iso)) <= CAL_FOLGA_OFICIAL)) return { ok: false, reason: `Há um jogo oficial a menos de ${CAL_FOLGA_OFICIAL + 1} dias.` };
  if (calDatasEstagio().includes(iso)) return { ok: false, reason: "Nessa data o plantel está em estágio." };
  if (calDatasPreparacao(opts.ignorarId).some(x => Math.abs(calDiff(x.iso, iso)) < CAL_FOLGA_AMIGAVEL)) return { ok: false, reason: "Já tens outro jogo de preparação nessa data ou no dia seguinte." };
  return { ok: true };
}
function calDataValidaTorneio(iso) {
  const a = calDataValida(iso, { antecedencia: CAL_ANTECEDENCIA_TORNEIO });
  if (!a.ok) return a;
  // O segundo dia tem de estar livre de jogos oficiais, estágios e outros jogos de preparação.
  const hoje = calHoje(), d2 = calIsoAdd(iso, 1);
  const max = calUltimaData();
  if (!max || d2 > max) return { ok: false, reason: "O segundo dia do torneio sai do período permitido." };
  if ([...calDatasOficiais()].some(o => Math.abs(calDiff(o, d2)) <= CAL_FOLGA_OFICIAL)) return { ok: false, reason: "O 2.º dia do torneio fica a menos de 3 dias de um jogo oficial." };
  if (calDatasEstagio().includes(d2)) return { ok: false, reason: "No 2.º dia o plantel está em estágio." };
  if (calDatasPreparacao().some(x => Math.abs(calDiff(x.iso, d2)) < CAL_FOLGA_AMIGAVEL)) return { ok: false, reason: "O 2.º dia do torneio choca com outro jogo de preparação." };
  return { ok: true };
}
// O adversário tem jogo oficial (liga ou Taça) perto desta data?
function calAdvOcupado(teamId, iso, folga) {
  folga = folga != null ? folga : CAL_FOLGA_OFICIAL;
  try {
    const compId = competitionIdForTeam(teamId);
    const comp = compId && state.competitions[compId];
    if (comp && comp.fixtures) {
      for (const round of comp.fixtures) {
        if (!round || !round.date) continue;
        if (Math.abs(calDiff(isoDate(round.date), iso)) > folga) continue;
        if (round.some(f => f.home === teamId || f.away === teamId)) return true;
      }
    }
    if (typeof amigDatasEliteCup === "function" && amigDatasEliteCup(teamId).some(d => Math.abs(calDiff(d, iso)) <= folga)) return true;
    const ip = state.calAmig && state.calAmig.iaPlano;
    if (ip && ip.epoca === state.season && ip.jogos.some(g => !g.played && (g.home === teamId || g.away === teamId) && Math.abs(calDiff(g.date, iso)) <= 1)) return true;
    if (state.tacaPortugal && typeof TACA_FASES !== "undefined") {
      for (const fase of TACA_FASES) {
        for (const j of (state.tacaPortugal.jogos[fase] || [])) {
          if (j.date && (j.home === teamId || j.away === teamId) && Math.abs(calDiff(isoDate(j.date), iso)) <= folga) return true;
        }
      }
    }
  } catch (e) {}
  return false;
}
function calOpcoesAdversario() {
  try { return preSeasonOpponentOptions(); } catch (e) { return []; }
}

// ---------------------------------------------------------------- Aceitação da IA
function calAvaliarConvite(opp, opts) {
  // opts: { casa:boolean (o utilizador joga em casa → o convidado desloca-se), iso, torneio:boolean }
  const me = myTeam();
  const rm = me.reputacaoClube || 50, ro = opp.reputacaoClube || 50;
  let s = 58 + clamp((rm - ro) * 0.3, -18, 14);
  let motivo = "Calendário preenchido";
  if (teamCountry(opp) !== teamCountry(me)) { s -= 12; motivo = "Deslocação demasiado complicada"; }
  s += opts.casa ? -6 : 8;
  if (opts.torneio) s -= 6;
  const datas = opts.torneio ? [opts.iso, calIsoAdd(opts.iso, 1)] : [opts.iso];
  if (datas.some(d => calAdvOcupado(opp.id, d))) { s -= 45; motivo = "Tem jogos oficiais por perto dessas datas"; }
  else if (ro - rm > 18) { motivo = "Prefere defrontar clubes do seu nível"; }
  s += (Math.random() - 0.5) * 20;
  return { score: s, aceita: s >= CAL_ACEITA_MIN, motivo };
}
function calRecusaAtiva(teamId) {
  const c = calEnsure();
  const r = c.recusas[teamId];
  return r && calDiff(calHoje(), r) < CAL_RECUSA_DIAS ? calIsoAdd(r, CAL_RECUSA_DIAS) : null;
}
function calDataResposta() { return calIsoAdd(calHoje(), CAL_RESP_MIN + Math.floor(Math.random() * (CAL_RESP_MAX - CAL_RESP_MIN + 1))); }

// ---------------------------------------------------------------- Amigáveis
function calPropor(opts) {
  const c = calEnsure(), me = myTeam();
  if (!me) return { ok: false, reason: "Sem clube." };
  const opp = state.teams[opts && opts.oppId];
  if (!opp || !calOpcoesAdversario().some(t => t.id === opp.id)) return { ok: false, reason: "Adversário inválido." };
  const v = calDataValida(opts.date);
  if (!v.ok) return v;
  const bloq = calRecusaAtiva(opp.id);
  if (bloq) return { ok: false, reason: `${opp.name} recusou há pouco; só volta a aceitar propostas a partir de ${calDataCurta(bloq)}.` };
  if (c.pedidos.some(p => p.estado === "pendente" && p.oppId === opp.id)) return { ok: false, reason: `Já aguardas resposta de ${opp.name}.` };
  const p = { id: calNovoId("ped"), tipo: "amigavel", oppId: opp.id, casa: opts.casa !== false, date: opts.date, pedidoEm: calHoje(), resposta: calDataResposta(), estado: "pendente", motivo: "" };
  c.pedidos.push(p);
  return { ok: true, pedido: p };
}
function calResolverAmigavel(p) {
  const me = myTeam(), opp = state.teams[p.oppId];
  if (!opp) { p.estado = "recusada"; p.motivo = "Clube indisponível"; return; }
  const v = calDataValida(p.date, { ignorarId: p.id, antecedencia: 1 });
  let aval = calAvaliarConvite(opp, { casa: p.casa, iso: p.date });
  if (!v.ok) aval = { aceita: false, motivo: "A data deixou de estar disponível no teu calendário" };
  const lado = p.casa ? "em casa" : "fora";
  if (aval.aceita) {
    p.estado = "aceite";
    const g = {
      id: calNovoId("amig"), date: p.date, home: p.casa ? me.id : opp.id, away: p.casa ? opp.id : me.id, oppId: opp.id, casa: p.casa,
      played: false, cancelled: false, homeScore: 0, awayScore: 0, custo: preSeasonFriendlyCost(p.casa), amigavel: true, origem: "cal",
    };
    calEnsure().jogos.push(g);
    calEnsure().jogos.sort((a, b) => a.date < b.date ? -1 : 1);
    pushNews(state.currentDate, `🤝 ${teamLinkHtml(opp.id)} aceitou o convite: jogo de preparação ${lado}, a ${calDataLonga(p.date)}.`, "sistema", "Amigável confirmado", { teamId: opp.id, autoAdvanceStop: true });
  } else {
    p.estado = "recusada"; p.motivo = aval.motivo;
    calEnsure().recusas[opp.id] = calHoje();
    pushNews(state.currentDate, `${teamLinkHtml(opp.id)} recusou o convite para um jogo de preparação ${lado} em ${calDataCurta(p.date)}. Motivo: ${aval.motivo.toLowerCase()}.`, "sistema", "Amigável recusado", { teamId: opp.id, autoAdvanceStop: true });
  }
}
function calCancelarAmigavel(id) {
  const c = calEnsure();
  const g = c.jogos.find(x => x.id === id);
  if (!g || g.played || g.cancelled) return { ok: false, reason: "Este jogo já não pode ser cancelado." };
  if (g.date <= calHoje()) return { ok: false, reason: "O jogo é hoje e já não pode ser cancelado." };
  g.cancelled = true;
  return { ok: true };
}
function calCancelarPedido(id) {
  const c = calEnsure();
  const p = c.pedidos.find(x => x.id === id);
  if (!p || p.estado !== "pendente") return { ok: false, reason: "Esta proposta já foi respondida." };
  p.estado = "retirada";
  return { ok: true };
}

// ---------------------------------------------------------------- Quadrangulares
function calTorneioPorId(id) { return calEnsure().torneios.find(t => t.id === id) || null; }
function calNomeTorneio(hostId) {
  const h = state.teams[hostId];
  const cidade = h && h.cidadePavilhao ? String(h.cidadePavilhao).split(",")[0].trim() : (h ? h.name : "");
  return `Quadrangular de ${cidade}`;
}
function calProporTorneio(opts) {
  const c = calEnsure(), me = myTeam();
  const modo = opts && opts.modo === "fora" ? "fora" : "casa";
  const v = calDataValidaTorneio(opts && opts.date);
  if (!v.ok) return v;
  const lista = calOpcoesAdversario();
  const idsOk = id => lista.some(t => t.id === id);
  const emEspera = new Set();
  c.pedidos.forEach(p => { if (p.estado === "pendente") emEspera.add(p.oppId); });
  c.torneios.forEach(t => { if (t.estado === "convites") t.convites.forEach(x => { if (x.estado === "pendente") emEspera.add(x.teamId); }); });
  let convites;
  if (modo === "casa") {
    const ids = (opts.convidados || []).filter(Boolean);
    if (ids.length !== 3 || new Set(ids).size !== 3) return { ok: false, reason: "Escolhe três clubes diferentes para convidar." };
    for (const id of ids) {
      if (!idsOk(id)) return { ok: false, reason: "Há um clube convidado inválido." };
      const bloq = calRecusaAtiva(id);
      if (bloq) return { ok: false, reason: `${state.teams[id].name} recusou há pouco (volta a aceitar a partir de ${calDataCurta(bloq)}).` };
      if (emEspera.has(id)) return { ok: false, reason: `Já aguardas resposta de ${state.teams[id].name}.` };
    }
    convites = ids.map(id => ({ teamId: id, estado: "pendente", resposta: calDataResposta(), motivo: "" }));
  } else {
    const host = opts.hostId;
    if (!idsOk(host)) return { ok: false, reason: "Escolhe o clube anfitrião." };
    const bloq = calRecusaAtiva(host);
    if (bloq) return { ok: false, reason: `${state.teams[host].name} recusou há pouco (volta a aceitar a partir de ${calDataCurta(bloq)}).` };
    if (emEspera.has(host)) return { ok: false, reason: `Já aguardas resposta de ${state.teams[host].name}.` };
    convites = [{ teamId: host, estado: "pendente", resposta: calDataResposta(), motivo: "" }];
  }
  const anf = modo === "casa" ? me.id : opts.hostId;
  const t = {
    id: calNovoId("torn"), tipo: "quadrangular", nome: calNomeTorneio(anf), modo, anfitriao: anf, data1: opts.date, data2: calIsoAdd(opts.date, 1),
    estado: "convites", criadoEm: calHoje(), convites, participantes: [me.id], jogos: [], iniciado: false, custo: 0, resultado: null,
  };
  c.torneios.push(t);
  return { ok: true, torneio: t };
}
function calEscolherCompanheiros(host, excluir, iso) {
  const me = myTeam();
  const pais = teamCountry(state.teams[host]);
  const cand = Object.values(state.teams).filter(t => t && t.id !== host && t.id !== me.id && !excluir.includes(t.id) && !t.equipaPrincipalId && !t.nuvemEuropeia && !t.selecaoNacional &&
    Array.isArray(t.players) && t.players.length >= 5 && teamCountry(t) === pais && !calAdvOcupado(t.id, iso) && !calAdvOcupado(t.id, calIsoAdd(iso, 1)));
  const rh = state.teams[host].reputacaoClube || 50;
  cand.sort((a, b) => Math.abs((a.reputacaoClube || 50) - rh) - Math.abs((b.reputacaoClube || 50) - rh));
  return cand.slice(0, 6);
}
function calResolverConviteTorneio(t, cv) {
  const opp = state.teams[cv.teamId];
  const me = myTeam();
  if (!opp) { cv.estado = "recusada"; cv.motivo = "Clube indisponível"; return; }
  let aval = calAvaliarConvite(opp, { casa: t.modo === "casa", iso: t.data1, torneio: true });
  if (!calDataValidaTorneio(t.data1).ok && calDiff(t.data1, calHoje()) < 1) aval = { aceita: false, motivo: "A data deixou de estar disponível" };
  if (aval.aceita) {
    cv.estado = "aceite";
    if (t.modo === "fora") {
      const comp = calEscolherCompanheiros(opp.id, [], t.data1);
      if (comp.length < 2) { cv.estado = "recusada"; cv.motivo = "Não conseguiu reunir mais dois clubes"; }
      else {
        const pick = [comp[0], comp[1 + Math.floor(Math.random() * Math.min(3, comp.length - 1))]];
        t.participantes = [opp.id, me.id, pick[0].id, pick[1].id];
        t.estado = "confirmado";
        pushNews(state.currentDate, `🏆 ${teamLinkHtml(opp.id)} aceitou receber-te: ${escapeHtml(t.nome)} a ${calDataCurta(t.data1)} e ${calDataCurta(t.data2)}, com ${teamLinkHtml(pick[0].id)} e ${teamLinkHtml(pick[1].id)}.`, "sistema", "Quadrangular confirmado", { teamId: opp.id, autoAdvanceStop: true });
        return;
      }
    }
  } else {
    cv.estado = "recusada"; cv.motivo = aval.motivo || "Calendário preenchido";
    calEnsure().recusas[opp.id] = calHoje();
  }
  if (cv.estado === "recusada") {
    pushNews(state.currentDate, `${teamLinkHtml(opp.id)} recusou o convite para o ${escapeHtml(t.nome)}. Motivo: ${String(cv.motivo).toLowerCase()}.${t.modo === "casa" ? " Podes convidar outro clube no Calendário." : ""}`, "sistema", "Convite recusado", { teamId: opp.id, autoAdvanceStop: true });
    if (t.modo === "fora") { t.estado = "cancelado"; return; }
  }
  if (t.modo === "casa" && t.convites.every(x => x.estado !== "pendente") && t.convites.every(x => x.estado === "aceite")) {
    t.estado = "confirmado";
    t.participantes = [me.id].concat(t.convites.map(x => x.teamId));
    pushNews(state.currentDate, `🏆 ${escapeHtml(t.nome)} confirmado para ${calDataCurta(t.data1)} e ${calDataCurta(t.data2)}: ${t.participantes.map(id => teamLinkHtml(id)).join(", ")}.`, "sistema", "Quadrangular confirmado", { autoAdvanceStop: true });
  }
}
function calSubstituirConvidado(id, antigoId, novoId) {
  const t = calTorneioPorId(id);
  if (!t || t.estado !== "convites" || t.modo !== "casa") return { ok: false, reason: "Este torneio já não aceita substituições." };
  const cv = t.convites.find(x => x.teamId === antigoId && x.estado === "recusada");
  if (!cv) return { ok: false, reason: "Só se substituem clubes que recusaram." };
  if (!calOpcoesAdversario().some(x => x.id === novoId)) return { ok: false, reason: "Clube inválido." };
  if (t.convites.some(x => x.teamId === novoId)) return { ok: false, reason: "Esse clube já está convidado." };
  const bloq = calRecusaAtiva(novoId);
  if (bloq) return { ok: false, reason: `${state.teams[novoId].name} recusou há pouco.` };
  cv.teamId = novoId; cv.estado = "pendente"; cv.resposta = calDataResposta(); cv.motivo = "";
  return { ok: true };
}
function calCancelarTorneio(id) {
  const t = calTorneioPorId(id);
  if (!t || !(t.estado === "convites" || t.estado === "confirmado")) return { ok: false, reason: "Este torneio já não pode ser cancelado." };
  if (calDiff(t.data1, calHoje()) < 1) return { ok: false, reason: "O torneio começa hoje e já não pode ser cancelado." };
  t.estado = "cancelado";
  return { ok: true };
}
function calTorneioCusto(t) {
  const me = myTeam();
  if (t.anfitriao === me.id) return Math.round(preSeasonFriendlyCost(true) * CAL_TORNEIO_CUSTO_CASA / 50) * 50;
  return Math.round(preSeasonFriendlyCost(false) * CAL_TORNEIO_CUSTO_FORA / 50) * 50;
}
function calJogoTorneio(t, fase, a, b, iso) {
  const me = myTeam();
  let home = a, away = b;
  if (a === t.anfitriao || b === t.anfitriao) { home = t.anfitriao; away = a === t.anfitriao ? b : a; }
  else if (a === me.id || b === me.id) { home = a === me.id ? b : a; away = me.id; }
  const meu = home === me.id || away === me.id;
  return {
    id: `${t.id}-${fase}`, torneioId: t.id, fase, date: iso, home, away, oppId: meu ? (home === me.id ? away : home) : null, casa: home === me.id,
    played: false, cancelled: false, homeScore: 0, awayScore: 0, vencedor: null, soWinner: false, custo: 0, amigavel: true, origem: "torneio",
  };
}
const CAL_FASE_LABEL = { sf1: "Meia-final", sf2: "Meia-final", final: "Final", terceiro: "3.º e 4.º lugar" };
function calDesempate(homeId, awayId) {
  const rh = (state.teams[homeId].reputacaoClube || 50), ra = (state.teams[awayId].reputacaoClube || 50);
  return Math.random() < 0.5 + clamp((rh - ra) / 400, -0.1, 0.1) ? homeId : awayId;
}
function calSimularJogo(g) {
  const anterior = state.pendingAmigavel;
  state.pendingAmigavel = true;   // o motor trata-o como jogo de preparação (nada conta)
  try {
    var addH = ensureMinimumSquad(state.teams[g.home]), addA = ensureMinimumSquad(state.teams[g.away]);
    const r = simulateMatchToCompletion(g.home, g.away, false, true, null);
    removeProvisionalPlayers(state.teams[g.home], addH); removeProvisionalPlayers(state.teams[g.away], addA);
    g.homeScore = r.home; g.awayScore = r.away;
    if (typeof amigIAEfeitos === "function") {
      const rh = r.home > r.away ? "V" : r.home < r.away ? "D" : "E";
      amigIAEfeitos(state.teams[g.home], rh); amigIAEfeitos(state.teams[g.away], rh === "V" ? "D" : rh === "D" ? "V" : "E");
    }
  } finally { state.pendingAmigavel = anterior; }
  calFecharJogoTorneio(calTorneioPorId(g.torneioId), g);
}
function calFecharJogoTorneio(t, g) {
  g.played = true;
  if (g.homeScore === g.awayScore) { g.soWinner = true; g.vencedor = calDesempate(g.home, g.away); }
  else g.vencedor = g.homeScore > g.awayScore ? g.home : g.away;
  const q = t.jogos.find(x => x.id === g.id);
  if (q && q !== g) Object.assign(q, { played: true, homeScore: g.homeScore, awayScore: g.awayScore, soWinner: g.soWinner, vencedor: g.vencedor });
  calTorneioProgresso(t);
}
function calTorneioIniciar(t) {
  const me = myTeam();
  t.iniciado = true; t.estado = "em_curso";
  t.custo = calTorneioCusto(t);
  if (t.custo > 0) addFinanceMovement(me, "despesa", "Jogos de preparação", t.anfitriao === me.id ? `Organização do ${t.nome}` : `Participação no ${t.nome} (deslocação e inscrição)`, t.custo, state.currentDate);
  const p = t.participantes.slice().sort(() => Math.random() - 0.5);
  t.jogos = [calJogoTorneio(t, "sf1", p[0], p[3], t.data1), calJogoTorneio(t, "sf2", p[1], p[2], t.data1)];
  pushNews(state.currentDate, `🏆 Arranca o ${escapeHtml(t.nome)}: ${t.jogos.map(g => `${teamLinkHtml(g.home)} – ${teamLinkHtml(g.away)}`).join(" e ")}.`, "jogo", "Arranca o quadrangular");
}
// Cria a final e o 3.º/4.º lugar quando as duas meias-finais terminam; fecha o torneio no fim.
function calTorneioProgresso(t) {
  const sf = t.jogos.filter(g => g.fase === "sf1" || g.fase === "sf2");
  if (sf.length === 2 && sf.every(g => g.played) && !t.jogos.some(g => g.fase === "final")) {
    const venc = sf.map(g => g.vencedor), perd = sf.map(g => g.vencedor === g.home ? g.away : g.home);
    t.jogos.push(calJogoTorneio(t, "terceiro", perd[0], perd[1], t.data2), calJogoTorneio(t, "final", venc[0], venc[1], t.data2));
  }
  const fin = t.jogos.find(g => g.fase === "final"), ter = t.jogos.find(g => g.fase === "terceiro");
  if (fin && ter && fin.played && ter.played && t.estado !== "concluido") calTorneioConcluir(t, fin, ter);
}
function calTorneioConcluir(t, fin, ter) {
  const me = myTeam();
  const ordem = [fin.vencedor, fin.vencedor === fin.home ? fin.away : fin.home, ter.vencedor, ter.vencedor === ter.home ? ter.away : ter.home];
  const pos = ordem.indexOf(me.id) + 1;
  const premio = Math.round((CAL_PREMIOS[pos] || 0) * (CAL_DIV_FATOR[teamDivisionRank(me)] || 0.15) / 50) * 50;
  t.estado = "concluido";
  t.resultado = { ordem, posicao: pos, premio };
  if (premio > 0) addFinanceMovement(me, "receita", "Prémio de torneio", `${t.nome}: ${pos}.º lugar`, premio, state.currentDate);
  const tabela = ordem.map((id, i) => `${i + 1}.º ${teamLinkHtml(id)}`).join(" · ");
  const txt = pos === 1 ? "Ganhaste o torneio!" : pos === 2 ? "Perdeste a final." : `Terminaste em ${pos}.º lugar.`;
  pushNews(state.currentDate, `🏆 Fim do ${escapeHtml(t.nome)}. ${txt} ${tabela}.${premio > 0 ? ` Prémio: ${fmtMoney(premio)}.` : ""}`, "jogo", pos === 1 ? "Campeão do quadrangular" : "Fim do quadrangular", { autoAdvanceStop: true });
  calEnsure().historico.push({ epoca: state.season, nome: t.nome, data: t.data2, posicao: pos, campeao: ordem[0], premio });
  if (pos === 1) { const b = ensureBalneario(me); if (b) b.coesao = clamp(b.coesao + 1.2, 3, 99); }
}
// Chamado depois de um jogo do utilizador num torneio (via recordFriendlyResult).
function calTorneioResultado(g, hs, as) {
  const t = calTorneioPorId(g.torneioId);
  if (!t) return;
  const j = t.jogos.find(x => x.id === g.id) || g;
  j.homeScore = hs; j.awayScore = as;
  calFecharJogoTorneio(t, j);
  const me = myTeam();
  const lbl = CAL_FASE_LABEL[g.fase];
  const mineVenceu = j.vencedor === me.id;
  pushNews(state.currentDate, `🏆 ${escapeHtml(t.nome)} — ${lbl}: ${teamLinkHtml(j.home)} ${hs}-${as} ${teamLinkHtml(j.away)}${j.soWinner ? " (decidido nos penáltis)" : ""}. ${(g.fase === "sf1" || g.fase === "sf2") ? (mineVenceu ? "Estás na final!" : "Vais jogar o 3.º e 4.º lugar amanhã.") : (mineVenceu ? "Vitória." : "Derrota.")}`, "jogo", `${t.nome}: ${lbl}`);
}

// ---------------------------------------------------------------- Dia a dia
function calPrepararJogoUser(g, texto) {
  const mine = myTeam();
  state.pendingProvisional = { mine: ensureMinimumSquad(mine), opp: ensureMinimumSquad(state.teams[g.oppId]) };
  state.pendingFixture = g; state.pendingAmigavel = true;
  generatePreGameReport(g, texto, null);
  state.matchDayReady = true;
}
function calAmigDiario() {
  const c = state.calAmig;
  if (!c) return;
  const hoje = calHoje();
  if (typeof amigIADiario === "function") { amigIADiario(); amigConvitesDiario(); }
  c.pedidos.forEach(p => {
    if (p.estado === "pendente" && p.resposta <= hoje) {
      if (p.tipo === "amigavel") calResolverAmigavel(p);
    }
  });
  c.torneios.forEach(t => {
    if (t.estado !== "convites") return;
    t.convites.forEach(cv => { if (cv.estado === "pendente" && cv.resposta <= hoje && t.estado === "convites") calResolverConviteTorneio(t, cv); });
    if (t.estado === "convites" && calDiff(t.data1, hoje) <= 2) {
      t.estado = "cancelado";
      pushNews(state.currentDate, `O ${escapeHtml(t.nome)} foi cancelado: faltavam clubes confirmados a menos de 3 dias do arranque.`, "sistema", "Quadrangular cancelado", { autoAdvanceStop: true });
    }
  });
  // Limpa pedidos antigos já respondidos (mantém os últimos 12).
  const antigos = c.pedidos.filter(p => p.estado !== "pendente");
  if (antigos.length > 12) c.pedidos = c.pedidos.filter(p => p.estado === "pendente" || antigos.slice(-12).includes(p));
}
// Chamado todos os dias a partir de processPreSeasonForCurrentDate (08e). Devolve true se
// preparou um jogo do utilizador para hoje.
function calAmigProcessarHoje() {
  const c = state.calAmig;
  if (!c || !state.userTeamId) return false;
  const hoje = calHoje(), today = state.currentDate;
  for (const g of c.jogos) {
    if (g.played || g.cancelled) continue;
    const d = new Date(g.date);
    if (d > today && !sameDay(d, today)) continue;
    if (!sameDay(d, today) && (today - d) / 86400000 > 1) {
      g.cancelled = true;
      pushNews(today, `O jogo de preparação com ${teamLinkHtml(g.oppId)} foi cancelado: não foi possível realizá-lo na data marcada.`, "sistema", "Amigável cancelado");
      continue;
    }
    if (state.matchDayReady || state.pendingFixture) return false;
    calPrepararJogoUser(g, "Jogo de preparação");
    return true;
  }
  for (const t of c.torneios) {
    if (t.estado !== "confirmado" && t.estado !== "em_curso") continue;
    if (hoje < t.data1) continue;
    if (!t.iniciado) {
      if (hoje > t.data1) { t.estado = "cancelado"; pushNews(today, `O ${escapeHtml(t.nome)} não se realizou (a data passou sem arrancar).`, "sistema", "Quadrangular cancelado"); continue; }
      calTorneioIniciar(t);
    }
    // Jogos de hoje (ou em atraso) que não envolvem o utilizador: simulam-se logo.
    for (const g of t.jogos.slice()) {
      if (g.played || g.date > hoje) continue;
      if (g.oppId == null) calSimularJogo(g);
    }
    const meu = t.jogos.find(g => !g.played && g.oppId != null && g.date <= hoje);
    if (meu) {
      if (state.matchDayReady || state.pendingFixture) return false;
      calPrepararJogoUser(meu, `${t.nome} — ${CAL_FASE_LABEL[meu.fase]}`);
      return true;
    }
  }
  return false;
}
function calAmigAmanha() {
  const c = state.calAmig; if (!c) return false;
  const amanha = calIsoAdd(calHoje(), 1);
  const g = c.jogos.find(x => !x.played && !x.cancelled && x.date === amanha);
  if (g) {
    pushNews(state.currentDate, `Jogo de preparação amanhã: ${teamLinkHtml(g.home)} vs ${teamLinkHtml(g.away)}${g.casa ? ", em casa" : ", fora"}. O resultado não conta para nenhuma competição.`, "jogo", "Jogo de preparação amanhã");
    generatePreGameReport(g, "Jogo de preparação", null);
    return true;
  }
  const t = c.torneios.find(x => (x.estado === "confirmado" && x.data1 === amanha) || (x.estado === "em_curso" && x.data2 === amanha));
  if (t) {
    pushNews(state.currentDate, `${escapeHtml(t.nome)}: ${t.data1 === amanha ? "arranca amanhã com as meias-finais" : "amanhã é dia de final e de 3.º e 4.º lugar"}.`, "jogo", `${t.nome} amanhã`);
    return true;
  }
  return false;
}
// Linhas para o contador "próximo jogo" e para o calendário.
function calAmigProximaLinha() {
  const c = state.calAmig; if (!c) return null;
  const hoje = calHoje();
  const cand = [];
  c.jogos.forEach(g => { if (!g.played && !g.cancelled && g.date >= hoje) cand.push({ date: g.date, label: "Jogo de preparação" }); });
  c.torneios.forEach(t => {
    if (t.estado === "confirmado" && t.data1 >= hoje) cand.push({ date: t.data1, label: t.nome });
    if (t.estado === "em_curso" && t.data2 >= hoje && t.jogos.some(g => !g.played && g.oppId != null)) cand.push({ date: t.data2, label: t.nome });
  });
  cand.sort((a, b) => a.date < b.date ? -1 : 1);
  return cand[0] || null;
}
function calAmigLinhasCalendario() {
  const out = [];
  const me = state.userTeamId;
  const ps = state.preSeason && state.preSeason.epoca === state.season ? state.preSeason : null;
  const push = (g, comp) => {
    if (!g || g.cancelled) return;
    const opp = g.oppId;
    out.push({
      date: g.date, competicao: comp, oppId: opp, local: g.casa === false ? "F" : "C", played: !!g.played,
      meu: g.played ? (g.home === me ? g.homeScore : g.awayScore) : null, seu: g.played ? (g.home === me ? g.awayScore : g.homeScore) : null, amigavel: true, id: g.id,
    });
  };
  if (ps) ps.amigaveis.forEach(g => push(g, "Jogo de preparação"));
  calEnsure().jogos.forEach(g => push(g, "Jogo de preparação"));
  calEnsure().torneios.forEach(t => {
    if (t.estado === "em_curso" || t.estado === "concluido") t.jogos.forEach(g => { if (g.oppId != null) push(g, `${t.nome} — ${CAL_FASE_LABEL[g.fase]}`); });
  });
  return out;
}

// ---------------------------------------------------------------- Calendário mensal (componente)
const CAL_DIAS_SEMANA = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"];
// cellFn(iso) -> { cls, html, attrs } ; compacto = versão pequena (seletor de data)
function calGridHtml(mes, cellFn, compacto) {
  const y = +mes.slice(0, 4), m = +mes.slice(5, 7) - 1;
  const primeiro = new Date(Date.UTC(y, m, 1));
  const offset = (primeiro.getUTCDay() + 6) % 7;
  const dias = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  let h = `<div class="calgrid${compacto ? " calgrid-c" : ""}">` + CAL_DIAS_SEMANA.map(d => `<div class="calgrid-h">${d}</div>`).join("");
  for (let i = 0; i < offset; i++) h += '<div class="calcell calcell-vazio"></div>';
  for (let d = 1; d <= dias; d++) {
    const iso = `${mes}-${calPad(d)}`;
    const c = cellFn(iso) || {};
    h += `<div class="calcell ${c.cls || ""}" data-iso="${iso}" ${c.attrs || ""}><span class="calnum">${d}</span>${c.html || ""}</div>`;
  }
  return h + "</div>";
}
// Seletor de data compacto (modal de pré-época). Elemento: <div class="calpk" data-valid data-mes data-value>
function calPickerHtml(id, validas, valor) {
  const mes = valor ? calMesDe(valor) : (validas.length ? calMesDe(validas[0]) : calMesDe(calHoje()));
  return `<div class="calpk" id="${id}" data-valid="${validas.join(",")}" data-mes="${mes}" data-value="${valor || ""}"></div>`;
}
function calPickerDraw(el) {
  if (!el) return;
  const validas = new Set((el.getAttribute("data-valid") || "").split(",").filter(Boolean));
  const mes = el.getAttribute("data-mes"), valor = el.getAttribute("data-value");
  const lista = [...validas].sort();
  const min = lista.length ? calMesDe(lista[0]) : mes, max = lista.length ? calMesDe(lista[lista.length - 1]) : mes;
  const grid = calGridHtml(mes, iso => {
    const ok = validas.has(iso);
    return { cls: `${ok ? "calcell-livre calpk-day" : "calcell-bloq"}${iso === valor ? " calcell-sel" : ""}`, attrs: ok ? "" : 'aria-disabled="true"' };
  }, true);
  el.innerHTML = `<div class="calpk-head"><button type="button" class="btn btn-ghost calpk-nav" data-dir="-1" ${mes <= min ? "disabled" : ""}>‹</button><b>${calMesLabel(mes)}</b><button type="button" class="btn btn-ghost calpk-nav" data-dir="1" ${mes >= max ? "disabled" : ""}>›</button></div>${grid}
    <div class="helptext" style="margin-top:4px;">${valor ? `Escolhido: <b>${calDataLonga(valor)}</b>` : "Escolhe um dia a verde."}</div>`;
}

// ---------------------------------------------------------------- Separador Calendário
function calOppSelectHtml(id, selecionado, iso, torneio) {
  const opts = calOpcoesAdversario();
  const grupos = {};
  opts.forEach(t => { const lab = competitionLabel(competitionIdForTeam(t.id)) || "Outros"; (grupos[lab] = grupos[lab] || []).push(t); });
  const html = Object.keys(grupos).map(lab => `<optgroup label="${escapeHtml(lab)}">${grupos[lab].map(t => {
    const ocupado = iso && (calAdvOcupado(t.id, iso) || (torneio && calAdvOcupado(t.id, calIsoAdd(iso, 1))));
    const recusa = calRecusaAtiva(t.id);
    return `<option value="${t.id}" ${t.id === selecionado ? "selected" : ""}>${ocupado ? "⚠ " : ""}${recusa ? "✗ " : ""}${escapeHtml(t.name)}</option>`;
  }).join("")}</optgroup>`).join("");
  return `<select id="${id}" class="cal-sel">${id.startsWith("calConv") ? '<option value="">— escolher —</option>' : ""}${html}</select>`;
}
function calFormHtml() {
  const iso = calUI.sel;
  if (!iso) return '<p class="helptext">Escolhe um dia a verde no calendário para propor um jogo de preparação ou um quadrangular.</p>';
  const lista = calDatasOficiais();
  const oficiais = calAmigLinhasDoDia(iso);
  if (oficiais.length) return `<div class="cal-detalhe"><b>${calDataLonga(iso)}</b><br>${oficiais.join("<br>")}</div>`;
  const vAm = calDataValida(iso), vTo = calDataValidaTorneio(iso);
  if (!vAm.ok && !vTo.ok) return `<div class="cal-detalhe"><b>${calDataLonga(iso)}</b><br><span class="helptext">${escapeHtml(vAm.reason)}</span></div>`;
  const modo = calUI.modo === "casa" && vTo.ok ? "casa" : calUI.modo === "fora" && vTo.ok ? "fora" : (vAm.ok ? "amigavel" : "casa");
  calUI.modo = modo;
  const tab = (m, txt, ok) => `<button class="btn ${modo === m ? "btn-primary" : "btn-ghost"} cal-modo" data-modo="${m}" ${ok ? "" : "disabled"}>${txt}</button>`;
  let corpo;
  const custoC = fmtMoney(preSeasonFriendlyCost(true)), custoF = fmtMoney(preSeasonFriendlyCost(false));
  if (modo === "amigavel") {
    if (!calUI.oppId) calUI.oppId = (calOpcoesAdversario()[0] || {}).id;
    corpo = `<label>Adversário<br>${calOppSelectHtml("calOpp", calUI.oppId, iso, false)}</label>
      <label>Local<br><select id="calCasa" class="cal-sel"><option value="1" ${calUI.casa === "1" ? "selected" : ""}>Em casa (${custoC})</option><option value="0" ${calUI.casa === "0" ? "selected" : ""}>Fora (${custoF})</option></select></label>
      <div class="helptext">O clube responde em 1 a 3 dias. Em casa tens bilheteira e bar, mas o adversário aceita menos vezes; fora é mais fácil de aceitar. ⚠ = o adversário tem jogo oficial por perto; ✗ = recusou recentemente.</div>
      <button class="btn btn-primary cal-enviar">Enviar proposta</button>`;
  } else if (modo === "casa") {
    corpo = [0, 1, 2].map(i => `<label>Convidado ${i + 1}<br>${calOppSelectHtml("calConv" + i, calUI.convidados[i], iso, true)}</label>`).join("") +
      `<div class="helptext">Organizas em casa: dois dias (${calDataCurta(iso)} e ${calDataCurta(calIsoAdd(iso, 1))}), custo de organização cerca de ${fmtMoney(Math.round(preSeasonFriendlyCost(true) * CAL_TORNEIO_CUSTO_CASA / 50) * 50)}, com bilheteira nos teus jogos e prémio ao 1.º ao 4.º lugar. Só se realiza se os três aceitarem.</div>
       <button class="btn btn-primary cal-enviar">Enviar convites</button>`;
  } else {
    if (!calUI.hostId) calUI.hostId = (calOpcoesAdversario()[0] || {}).id;
    corpo = `<label>Clube anfitrião<br>${calOppSelectHtml("calHost", calUI.hostId, iso, true)}</label>
      <div class="helptext">Pedes para jogar um quadrangular em casa de outro clube (${calDataCurta(iso)} e ${calDataCurta(calIsoAdd(iso, 1))}); se aceitar, ele junta mais dois clubes. Custo de participação cerca de ${fmtMoney(Math.round(preSeasonFriendlyCost(false) * CAL_TORNEIO_CUSTO_FORA / 50) * 50)}.</div>
      <button class="btn btn-primary cal-enviar">Enviar pedido</button>`;
  }
  return `<div class="cal-detalhe"><b>${calDataLonga(iso)}</b>
    <div class="cal-modos">${tab("amigavel", "Amigável", vAm.ok)} ${tab("casa", "Quadrangular em casa", vTo.ok)} ${tab("fora", "Quadrangular fora", vTo.ok)}</div>
    <div class="cal-form">${corpo}</div><div class="helptext" style="color:#d6402f;">${escapeHtml(calUI.erro || "")}</div></div>`;
}
// Jogos do utilizador num dia (para o painel de detalhe).
function calAmigLinhasDoDia(iso) {
  const out = [];
  let rows = [];
  try { rows = myFullSchedule(); } catch (e) {}
  rows.concat(calAmigLinhasCalendario()).forEach(r => {
    if (isoDate(r.date) !== iso) return;
    const opp = state.teams[r.oppId];
    out.push(`${escapeHtml(r.competicao)} — ${r.local === "C" ? "casa" : r.local === "F" ? "fora" : "neutro"} vs ${opp ? teamLinkHtml(r.oppId) : "?"}${r.played ? ` (${r.meu}-${r.seu})` : ""}`);
  });
  calEnsure().pedidos.forEach(p => { if (p.estado === "pendente" && p.date === iso) out.push(`Proposta de amigável a ${teamLinkHtml(p.oppId)} — aguarda resposta`); });
  calEnsure().torneios.forEach(t => { if ((t.estado === "convites" || t.estado === "confirmado" || t.estado === "em_curso") && (t.data1 === iso || t.data2 === iso)) out.push(`${escapeHtml(t.nome)} (${t.estado === "convites" ? "à espera de confirmação" : "confirmado"})`); });
  calDatasEstagio().includes(iso) && out.push("Estágio de pré-época");
  return out;
}
function calCelulaPrincipal(iso, oficiaisMap, prepMap) {
  const hoje = calHoje();
  const cls = [];
  let html = "";
  const r = oficiaisMap[iso];
  if (iso === hoje) cls.push("calcell-hoje");
  if (iso < hoje) cls.push("calcell-passado");
  if (r) {
    const opp = state.teams[r.oppId];
    cls.push("calcell-jogo");
    html += `<span class="calchip calchip-of" title="${escapeHtml(r.competicao)}">${r.local === "F" ? "@" : ""}${escapeHtml(calSigla(opp))}${r.played ? ` ${r.meu}-${r.seu}` : ""}</span>`;
  }
  const pr = prepMap[iso];
  if (pr) {
    cls.push("calcell-prep");
    html += pr.map(x => `<span class="calchip ${x.cls}" title="${escapeHtml(x.titulo)}">${escapeHtml(x.txt)}</span>`).join("");
  }
  if (!r && !pr && iso >= hoje) {
    const v = calDataValida(iso);
    if (v.ok) cls.push("calcell-livre");
    else if (!calDataValidaTorneio(iso).ok) cls.push("calcell-bloq");
  }
  if (iso === calUI.sel) cls.push("calcell-sel");
  return { cls: cls.join(" "), html, attrs: 'role="button"' };
}
function calPainelEstadoHtml() {
  const c = calEnsure();
  const linhas = [];
  const hoje = calHoje();
  const ps = state.preSeason && state.preSeason.epoca === state.season ? state.preSeason : null;
  (c.convites || []).filter(x => x.estado === "pendente").forEach(cv => {
    linhas.push(`<div class="cal-linha cal-convite"><span>${calDataCurta(cv.date)}</span><span>🤝 Convite de ${teamLinkHtml(cv.oppId)} · ${cv.casa ? "em tua casa" : "em casa deles"} · responde até ${calDataCurta(cv.expira)}</span><span class="num">${fmtMoney(preSeasonFriendlyCost(cv.casa))}</span><span class="cal-conv-btns"><button class="btn cal-conv-aceitar" data-id="${cv.id}">Aceitar</button><button class="btn btn-ghost cal-conv-recusar" data-id="${cv.id}">Recusar</button></span></div>`);
  });
  const futuros = [];
  if (ps) ps.amigaveis.forEach(g => { if (!g.cancelled && !g.played) futuros.push({ g, pre: true }); });
  c.jogos.forEach(g => { if (!g.cancelled && !g.played) futuros.push({ g }); });
  futuros.sort((a, b) => a.g.date < b.g.date ? -1 : 1);
  futuros.forEach(({ g, pre }) => {
    linhas.push(`<div class="cal-linha"><span>${calDataCurta(isoDate(g.date))}</span><span>Amigável · ${g.casa ? "casa" : "fora"} · ${teamLinkHtml(g.oppId)}</span><span class="num">${fmtMoney(g.custo)}</span>${pre ? "" : `<button class="btn btn-ghost cal-cancelar-jogo" data-id="${g.id}" ${g.date <= hoje ? "disabled" : ""}>Cancelar</button>`}</div>`);
  });
  c.pedidos.filter(p => p.estado === "pendente").forEach(p => {
    linhas.push(`<div class="cal-linha"><span>${calDataCurta(p.date)}</span><span>Proposta a ${teamLinkHtml(p.oppId)} (${p.casa ? "casa" : "fora"}) · resposta até ${calDataCurta(p.resposta)}</span><span></span><button class="btn btn-ghost cal-retirar-pedido" data-id="${p.id}">Retirar</button></div>`);
  });
  c.pedidos.filter(p => p.estado === "recusada").slice(-3).forEach(p => {
    linhas.push(`<div class="cal-linha cal-mute"><span>${calDataCurta(p.date)}</span><span>${teamLinkHtml(p.oppId)} recusou · ${escapeHtml(String(p.motivo || "").toLowerCase())}</span><span></span><span></span></div>`);
  });
  c.torneios.filter(t => t.estado !== "cancelado").forEach(t => {
    const est = { convites: "à espera de confirmação", confirmado: "confirmado", em_curso: "em curso", concluido: "concluído" }[t.estado];
    let det = "";
    if (t.estado === "convites") {
      det = t.convites.map(cv => {
        const tm = state.teams[cv.teamId];
        if (cv.estado === "recusada" && t.modo === "casa") return `<div class="cal-sub">✗ ${escapeHtml(tm ? tm.name : "?")} recusou (${escapeHtml(String(cv.motivo || "").toLowerCase())}) — substituir por ${calOppSelectHtml("calSubst-" + t.id + "-" + cv.teamId, "", t.data1, true).replace('<select ', '<select data-tid="' + t.id + '" data-antigo="' + cv.teamId + '" ')} <button class="btn btn-ghost cal-subst" data-tid="${t.id}" data-antigo="${cv.teamId}">Convidar</button></div>`;
        return `<div class="cal-sub">${cv.estado === "aceite" ? "✓" : cv.estado === "recusada" ? "✗" : "…"} ${escapeHtml(tm ? tm.name : "?")} ${cv.estado === "pendente" ? `· resposta até ${calDataCurta(cv.resposta)}` : cv.estado === "aceite" ? "· aceitou" : "· recusou"}</div>`;
      }).join("");
    } else if (t.estado === "confirmado" || t.estado === "em_curso") {
      det = `<div class="cal-sub">${t.participantes.map(id => teamLinkHtml(id)).join(" · ")}</div>` +
        (t.jogos.length ? t.jogos.map(g => `<div class="cal-sub">${CAL_FASE_LABEL[g.fase]} (${calDataCurta(g.date)}): ${escapeHtml(state.teams[g.home].name)} ${g.played ? `${g.homeScore}-${g.awayScore}` : "vs"} ${escapeHtml(state.teams[g.away].name)}${g.soWinner ? " (pen.)" : ""}</div>`).join("") : "");
    } else if (t.estado === "concluido" && t.resultado) {
      det = `<div class="cal-sub">${t.resultado.ordem.map((id, i) => `${i + 1}.º ${teamLinkHtml(id)}`).join(" · ")}${t.resultado.premio ? ` · prémio ${fmtMoney(t.resultado.premio)}` : ""}</div>`;
    }
    const pode = (t.estado === "convites" || t.estado === "confirmado") && calDiff(t.data1, hoje) >= 1;
    linhas.push(`<div class="cal-bloco"><div class="cal-linha"><span>${calDataCurta(t.data1)}–${calDataCurta(t.data2)}</span><span>🏆 <b>${escapeHtml(t.nome)}</b> · ${t.modo === "casa" ? "organizas em casa" : "fora"} · ${est}</span><span></span>${pode ? `<button class="btn btn-ghost cal-cancelar-torneio" data-id="${t.id}">Cancelar</button>` : "<span></span>"}</div>${det}</div>`);
  });
  if (c.historico.length) {
    const tr = c.historico.filter(h => h.posicao === 1).length;
    linhas.push(`<div class="helptext">Quadrangulares disputados: ${c.historico.length}${tr ? ` · ganhos: ${tr}` : ""}.</div>`);
  }
  return `<div class="eyebrow section-label" style="margin-top:14px;">Jogos de preparação e torneios</div>${linhas.length ? linhas.join("") : '<p class="helptext">Ainda não tens jogos de preparação nem torneios marcados.</p>'}`;
}
function calPainelHtml() {
  const hoje = calHoje();
  if (!calUI.mes) calUI.mes = calMesDe(hoje);
  const oficiaisMap = {};
  try { myFullSchedule().forEach(r => { oficiaisMap[isoDate(r.date)] = r; }); } catch (e) {}
  const prepMap = {};
  const addPrep = (iso, x) => { (prepMap[iso] = prepMap[iso] || []).push(x); };
  calAmigLinhasCalendario().forEach(r => {
    const opp = state.teams[r.oppId];
    const isT = r.competicao.indexOf("Quadrangular") >= 0 || r.competicao.indexOf(" — ") >= 0;
    addPrep(isoDate(r.date), { cls: isT ? "calchip-to" : "calchip-am", txt: `${isT ? "🏆" : "🤝"} ${calSigla(opp)}${r.played ? ` ${r.meu}-${r.seu}` : ""}`, titulo: r.competicao });
  });
  const c = calEnsure();
  c.pedidos.forEach(p => { if (p.estado === "pendente") addPrep(p.date, { cls: "calchip-pe", txt: `… ${calSigla(state.teams[p.oppId])}`, titulo: "Proposta por responder" }); });
  (c.convites || []).forEach(cv => { if (cv.estado === "pendente") addPrep(cv.date, { cls: "calchip-pe", txt: `✉ ${calSigla(state.teams[cv.oppId])}`, titulo: "Convite recebido: responde em Convites" }); });
  c.torneios.forEach(t => {
    if (t.estado === "convites") [t.data1, t.data2].forEach(d => addPrep(d, { cls: "calchip-pe", txt: "🏆 …", titulo: `${t.nome} (à espera de confirmação)` }));
    if (t.estado === "confirmado") [t.data1, t.data2].forEach(d => addPrep(d, { cls: "calchip-to", txt: "🏆", titulo: t.nome }));
  });
  calDatasEstagio().forEach(d => addPrep(d, { cls: "calchip-es", txt: "Estágio", titulo: "Estágio de pré-época" }));
  const grid = calGridHtml(calUI.mes, iso => calCelulaPrincipal(iso, oficiaisMap, prepMap), false);
  return `<div class="cal-topo"><button class="btn btn-ghost cal-mes-nav" data-dir="-1">‹</button><b class="cal-mes-titulo">${calMesLabel(calUI.mes)}</b><button class="btn btn-ghost cal-mes-nav" data-dir="1">›</button>
      <button class="btn btn-ghost cal-hoje">Hoje</button></div>
    ${grid}
    <div class="cal-legenda"><span class="calchip calchip-of">Oficial</span><span class="calchip calchip-am">🤝 Amigável</span><span class="calchip calchip-to">🏆 Torneio</span><span class="calchip calchip-pe">… Por responder</span><span class="cal-liv">Dia livre</span></div>
    <div id="calFormBox">${calFormHtml()}</div>
    ${calPainelEstadoHtml()}`;
}
function calRedesenhar() { if (typeof renderCalendarioView === "function") renderCalendarioView(); }

(function wireCalendarioUi() {
  document.addEventListener("click", e => {
    const t = e.target;
    if (!t || !t.closest) return;
    const abaBtn = t.closest("#calendarioTabs [data-cal-tab]");
    if (abaBtn) { calUI.aba = abaBtn.getAttribute("data-cal-tab") === "geral" ? "geral" : "mensal"; calRedesenhar(); return; }
    // seletor compacto (modal de pré-época)
    const pkDia = t.closest(".calpk-day");
    if (pkDia) {
      const pk = pkDia.closest(".calpk");
      pk.setAttribute("data-value", pkDia.getAttribute("data-iso")); calPickerDraw(pk);
      return;
    }
    const pkNav = t.closest(".calpk-nav");
    if (pkNav) {
      const pk = pkNav.closest(".calpk");
      pk.setAttribute("data-mes", calMesAdd(pk.getAttribute("data-mes"), +pkNav.getAttribute("data-dir"))); calPickerDraw(pk);
      return;
    }
    if (!t.closest("#viewCalendario")) return;
    const nav = t.closest(".cal-mes-nav");
    if (nav) { calUI.mes = calMesAdd(calUI.mes || calMesDe(calHoje()), +nav.getAttribute("data-dir")); calRedesenhar(); return; }
    if (t.closest(".cal-hoje")) { calUI.mes = calMesDe(calHoje()); calRedesenhar(); return; }
    const cel = t.closest(".calcell[data-iso]");
    if (cel) { calUI.sel = cel.getAttribute("data-iso"); calUI.erro = ""; calRedesenhar(); return; }
    const modo = t.closest(".cal-modo");
    if (modo) { calUI.modo = modo.getAttribute("data-modo"); calUI.erro = ""; calRedesenhar(); return; }
    if (t.closest(".cal-enviar")) {
      let r;
      if (calUI.modo === "amigavel") r = calPropor({ oppId: calUI.oppId, casa: calUI.casa === "1", date: calUI.sel });
      else if (calUI.modo === "casa") r = calProporTorneio({ modo: "casa", date: calUI.sel, convidados: calUI.convidados.slice() });
      else r = calProporTorneio({ modo: "fora", date: calUI.sel, hostId: calUI.hostId });
      if (!r.ok) { calUI.erro = r.reason; calRedesenhar(); return; }
      calUI.erro = ""; calUI.convidados = ["", "", ""];
      showTransientNotice(calUI.modo === "amigavel" ? "Proposta enviada. Resposta em 1 a 3 dias." : "Convite enviado. Resposta em 1 a 3 dias.");
      calRedesenhar(); return;
    }
    const cj = t.closest(".cal-cancelar-jogo");
    if (cj) { const r = calCancelarAmigavel(cj.getAttribute("data-id")); if (!r.ok) showTransientNotice(r.reason); calRedesenhar(); return; }
    const ca = t.closest(".cal-conv-aceitar"), cr = t.closest(".cal-conv-recusar");
    if (ca || cr) {
      const r = amigConviteResponder((ca || cr).getAttribute("data-id"), !!ca);
      if (!r.ok) showTransientNotice(r.reason); else showTransientNotice(ca ? "Convite aceite." : "Convite recusado.");
      calRedesenhar(); return;
    }
    const rp = t.closest(".cal-retirar-pedido");
    if (rp) { calCancelarPedido(rp.getAttribute("data-id")); calRedesenhar(); return; }
    const ct = t.closest(".cal-cancelar-torneio");
    if (ct) { const r = calCancelarTorneio(ct.getAttribute("data-id")); if (!r.ok) showTransientNotice(r.reason); calRedesenhar(); return; }
    const sb = t.closest(".cal-subst");
    if (sb) {
      const sel = document.querySelector(`select[data-tid="${sb.getAttribute("data-tid")}"][data-antigo="${sb.getAttribute("data-antigo")}"]`);
      const r = calSubstituirConvidado(sb.getAttribute("data-tid"), sb.getAttribute("data-antigo"), sel ? sel.value : "");
      if (!r.ok) showTransientNotice(r.reason); else showTransientNotice("Novo convite enviado.");
      calRedesenhar(); return;
    }
  });
  document.addEventListener("change", e => {
    const t = e.target;
    if (!t || !t.id || !t.closest || !t.closest("#viewCalendario")) return;
    if (t.id === "calOpp") calUI.oppId = t.value;
    else if (t.id === "calCasa") calUI.casa = t.value;
    else if (t.id === "calHost") calUI.hostId = t.value;
    else if (/^calConv\d$/.test(t.id)) calUI.convidados[+t.id.slice(-1)] = t.value;
  });
})();
