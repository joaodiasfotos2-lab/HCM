  // ============================= 07c-supertaca.js =============================
  // Supertaça António Livramento — jogo único de pré-época, em campo neutro (sem vantagem de
  // jogar em casa), entre o campeão nacional do Campeonato Placard e o vencedor da Taça de
  // Portugal da época anterior; se o mesmo clube tiver feito a "dobradinha" (venceu as duas
  // provas), joga em seu lugar o finalista vencido da Taça. Disputa-se sempre no 2.º sábado de
  // outubro (ver getSecondSaturdayOfOctober, em 01-nucleo.js) — a jornada 1 do Campeonato
  // Placard segue-se sempre no domingo imediatamente a seguir (getPlacardOpeningSunday).
  //
  // A 1.ª carreira de sempre não tem época anterior para apurar campeão/vencedor da Taça: usa-se
  // o par inaugural fixo definido no roteiro de implementação (Benfica vs. Sporting).
  //
  // Prémios e ganho de prestígio (parâmetros calibrados por simulação — o próprio roteiro deixa
  // estes valores em aberto): um único jogo de pré-época vale menos do que vencer uma prova
  // longa (Campeonato ou Taça), mas mais do que uma final sem promoção associada (2ª Divisão).
  const SUPERTACA_PRIZE_WINNER = 50000;
  const SUPERTACA_PRIZE_RUNNERUP = 20000;
  const SUPERTACA_PRESTIGE_WINNER = 1.5;

  // Emparelhamento a partir do resumo oficial da época que terminou (ver completedSummary, em
  // beginDefeso, 08-evolucao-jogadores.js). Devolve null quando não há dados suficientes (ex.:
  // save antigo carregado a meio de carreira, sem histórico da época anterior) — nesse caso a
  // Supertaça fica por disputar essa época, em vez de arriscar um sorteio sem suporte no
  // regulamento.
  function computeSupertacaQualification(summary){
    const campeaoId = summary && summary.champion || null;
    const tacaVencedorId = summary && summary.tacaVencedorId || null;
    const tacaFinalistaId = summary && summary.tacaFinalistaId || null;
    if(!campeaoId || !tacaVencedorId) return null;
    let adversarioId = tacaVencedorId, substituicaoDuploVencedor = false;
    if(tacaVencedorId===campeaoId){
      // Dobradinha: o campeão nacional também venceu a Taça de Portugal — joga em seu lugar o
      // finalista vencido da Taça.
      adversarioId = tacaFinalistaId;
      substituicaoDuploVencedor = true;
    }
    if(!adversarioId || adversarioId===campeaoId) return null;
    return { campeaoNacionalId:campeaoId, tacaVencedorId, tacaFinalistaId, adversarioId, substituicaoDuploVencedor };
  }

  // Início de época: monta a edição desta época (chamado uma vez, tal como initTacaPortugal) —
  // a partir de chooseClub() na 1.ª carreira (initialEditionOverride) ou de finalizeNewSeason()
  // em todas as seguintes (a partir do resumo da época anterior).
  function initSupertaca(options){
    options = options || {};
    if(!state.supertaca || typeof state.supertaca!=="object") state.supertaca = { historico:[], jogo:null };
    if(!Array.isArray(state.supertaca.historico)) state.supertaca.historico = [];
    // Idempotência: nunca recriar a edição desta mesma época duas vezes (mesma proteção usada em
    // todo o resto do jogo — ex.: state.financePrizeAwarded).
    if(state.supertaca.jogo && state.supertaca.jogo.epoca===state.season) return;
    if(state.supertaca.historico.some(e=>e.epoca===state.season)) return;

    const anoBase = 2025 + state.season;
    const data = getSecondSaturdayOfOctober(anoBase);
    let home, away, qualificacao;
    if(options.initialEditionOverride){
      home = "benfica"; away = "sporting";
      qualificacao = { campeaoNacionalId:null, tacaVencedorId:null, tacaFinalistaId:null, adversarioId:away, substituicaoDuploVencedor:false, origem:"primeira-edicao" };
    } else {
      const summary = options.summary || state.pendingSeasonSummary || state.lastSeasonSummary || {};
      const q = computeSupertacaQualification(summary);
      if(!q){ state.supertaca.jogo = null; return; }
      home = q.campeaoNacionalId; away = q.adversarioId; qualificacao = q;
    }
    if(!state.teams[home] || !state.teams[away]){
      console.error("Supertaça António Livramento: clube de qualificação inexistente — edição não gerada.", { home, away });
      state.supertaca.jogo = null; return;
    }
    // Correção (verificação pedida pelo utilizador): protege o 2.º sábado de outubro contra
    // qualquer outra prova já agendada para esse dia, com a mesma proteção genérica usada em
    // todas as restantes competições — antes, a Supertaça nunca verificava colisão nenhuma.
    // home/away já são conhecidos neste momento — protege-se apenas a disponibilidade real
    // desses dois clubes (3.3 da auditoria externa), não o dia inteiro.
    avoidLeagueCollisionsOnDate(data, "Supertaça António Livramento", [home, away]);
    state.supertaca.jogo = {
      epoca: state.season, seasonLabel: seasonLabel(state.season), date: new Date(data),
      home, away, homeScore:0, awayScore:0, soWinner:null, played:false, vencedor:null,
      qualificacao, financasAtribuidas:false, prestigioAtribuido:false,
    };
    const dobradinhaTxt = qualificacao.substituicaoDuploVencedor
      ? " (o campeão nacional também venceu a Taça de Portugal na época anterior — joga em seu lugar o finalista vencido)"
      : "";
    pushNews(state.currentDate, `Supertaça António Livramento ${seasonLabel(state.season)}: ${teamLinkHtml(home)} defronta ${teamLinkHtml(away)}, em campo neutro, a ${fmtDateLong(new Date(data))}${dobradinhaTxt}.`, "sistema", "Supertaça António Livramento", {autoAdvanceStop:true});
  }

  // Antevisão/relatório pré-jogo (chamados 1 dia antes, tal como tacaMyTieForCurrentDate) — só
  // faz sentido quando o clube do utilizador é um dos dois finalistas.
  function supertacaMyFixtureForCurrentDate(){
    const jogo = state.supertaca && state.supertaca.jogo;
    if(!jogo || jogo.played) return null;
    if(jogo.home!==state.userTeamId && jogo.away!==state.userTeamId) return null;
    return jogo;
  }
  function supertacaBuildPreviewNews(jogo){
    const title = `Supertaça António Livramento: ${state.teams[jogo.home].name} vs ${state.teams[jogo.away].name} amanhã, em campo neutro`;
    const rows = `<div class="jr-row jr-me">
      <span class="jr-pos"></span>
      <button class="jr-team-link jr-home" data-team="${jogo.home}">${state.teams[jogo.home].name}</button>
      <span class="jr-score">vs</span>
      <button class="jr-team-link jr-away" data-team="${jogo.away}">${state.teams[jogo.away].name}</button>
      <span class="jr-pos"></span>
    </div>`;
    pushNews(state.currentDate, rows, "jogo", title);
  }

  // Prémio financeiro, prestígio e título — atribuídos uma única vez por edição (idempotente:
  // as marcas financasAtribuidas/prestigioAtribuido protegem contra reprocessamento, ex.: ao
  // carregar um save feito imediatamente a seguir ao jogo). awardClubTitle já é idempotente por
  // si próprio (chave competição+época), tal como o resto do jogo.
  function supertacaAwardOutcome(jogo){
    if(!jogo || !jogo.played || !jogo.vencedor) return;
    const vencedorId = jogo.vencedor, finalistaId = vencedorId===jogo.home ? jogo.away : jogo.home;
    const vencedorTeam = state.teams[vencedorId], finalistaTeam = state.teams[finalistaId];
    if(vencedorTeam && !jogo.prestigioAtribuido){
      awardClubTitle(vencedorId, "supertaca", `Supertaça António Livramento ${jogo.seasonLabel||seasonLabel(jogo.epoca)}`);
      vencedorTeam.reputacaoPontos = clamp((vencedorTeam.reputacaoPontos!=null?vencedorTeam.reputacaoPontos:normalizeClubReputation(vencedorTeam.reputacao, vencedorTeam)) + SUPERTACA_PRESTIGE_WINNER, 5, 99);
      vencedorTeam.reputacao = reputationFromPoints(vencedorTeam.reputacaoPontos);
      jogo.prestigioAtribuido = true;
    }
    if(!jogo.financasAtribuidas){
      if(vencedorTeam) addFinanceMovement(vencedorTeam, "receita", "Prémio de competição", `Supertaça António Livramento ${jogo.seasonLabel||seasonLabel(jogo.epoca)} — vencedor`, SUPERTACA_PRIZE_WINNER, state.currentDate);
      if(finalistaTeam) addFinanceMovement(finalistaTeam, "receita", "Prémio de competição", `Supertaça António Livramento ${jogo.seasonLabel||seasonLabel(jogo.epoca)} — finalista`, SUPERTACA_PRIZE_RUNNERUP, state.currentDate);
      jogo.financasAtribuidas = true;
    }
  }

  function recordSupertacaResult(hs, as, soWinner){
    const s = state.supertaca, jogo = s && s.jogo;
    if(!jogo || jogo.played) return;
    jogo.played = true; jogo.homeScore = hs; jogo.awayScore = as; jogo.soWinner = soWinner||null;
    jogo.vencedor = hs>as ? jogo.home : as>hs ? jogo.away : (soWinner==="home"?jogo.home:soWinner==="away"?jogo.away:null);
    if(!jogo.vencedor){
      // Diagnóstico defensivo: isPlayoff=true (sempre, na Supertaça) já obriga o motor de jogo a
      // decidir por prolongamento/grandes penalidades — nunca deveria terminar sem vencedor.
      console.error("Supertaça António Livramento: jogo terminou sem vencedor definido.", jogo);
      return;
    }
    supertacaAwardOutcome(jogo);
    const finalistaId = jogo.vencedor===jogo.home ? jogo.away : jogo.home;
    const marcador = `${hs}-${as}${soWinner?' (g.p.)':''}`;
    pushNews(state.currentDate, `🏆 ${teamLinkHtml(jogo.vencedor)} venceu a Supertaça António Livramento ${jogo.seasonLabel||seasonLabel(jogo.epoca)}, por ${marcador}, frente a ${teamLinkHtml(finalistaId)}.`, "sistema", "Supertaça António Livramento — Resultado", {autoAdvanceStop:true});
    if(!Array.isArray(s.historico)) s.historico = [];
    if(!s.historico.some(e=>e.epoca===jogo.epoca)) s.historico.push({ ...jogo });
  }

  // Processamento diário — chamado a partir de processPhaseFiveFinalsForCurrentDate (tal como a
  // Taça de Portugal e as finais da 2ª Divisão): se o jogo é hoje e não envolve o clube do
  // utilizador, resolve-se logo (com prolongamento/grandes penalidades se necessário); se
  // envolve o utilizador, abre a convocatória interativa.
  function processSupertacaForCurrentDate(){
    const jogo = state.supertaca && state.supertaca.jogo;
    if(!jogo || jogo.played) return false;
    // Correção (bug real, teste alargado de 5 épocas): "chegou ou já passou" em vez de sameDay —
    // ver nota equivalente em processTacaPortugalForCurrentDate. Se o dia exato coincidir com o
    // de outra prova do utilizador e a vaga interativa já estiver ocupada (guarda abaixo), a
    // data exata passava e o jogo ficava pendente para sempre (supertaca.jogo nunca marcado como
    // jogado).
    if(!jogo.date || new Date(jogo.date) > state.currentDate) return false;
    const involvesUser = jogo.home===state.userTeamId || jogo.away===state.userTeamId;
    if(!involvesUser){
      const res = simulateMatchToCompletion(jogo.home, jogo.away, true, true, "supertaca"); // isPlayoff: força vencedor · neutralVenue: sempre
      recordSupertacaResult(res.home, res.away, res.soWinner);
      return true;
    }
    // Correção: vaga única (matchDayReady/pendingFixture) partilhada com o Playoff, a Taça de
    // Portugal e a Liguilha/Final da 2ª Divisão — se já estiver ocupada hoje por outra prova, não
    // se sobrepõe (isso corrompia o resultado da prova errada); o jogo fica por marcar até à
    // próxima chamada com a vaga livre.
    if(state.matchDayReady) return false;
    const oppId = jogo.home===state.userTeamId ? jogo.away : jogo.home;
    state.pendingProvisional = { mine: ensureMinimumSquad(myTeam()), opp: ensureMinimumSquad(state.teams[oppId]) };
    state.pendingFixture = jogo; state.pendingSupertaca = true;
    state.pendingSuspensionServing = { home:getSuspendedIds(jogo.home), away:getSuspendedIds(jogo.away) };
    generatePreGameReport(jogo, "Supertaça António Livramento", null);
    state.matchDayReady = true;
    return true;
  }
