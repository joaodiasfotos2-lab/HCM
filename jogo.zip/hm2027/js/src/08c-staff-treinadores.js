// Staff — Treinadores (2026-09-22, pedido do utilizador: "Quero criar staff a começar pelos
// treinadores. Todos os clubes têm um treinador com características próprias e um perfil, com
// stats"). Decisões fechadas com o utilizador:
// - Escala 0-20, igual à dos jogadores (clampAttr) — não 0-100 como o resto dos atributos de
//   clube (reputação, moral, etc.), que era a minha proposta inicial e foi explicitamente
//   corrigida: "Tem de ser 0-20 como os jogadores."
// - 12 stats propostos, aprovados tal como estavam, agrupados em duas categorias:
//   competência (afecta o quão bem o treinador executa, tende a subir com a reputação do clube)
//   e perfil (o "estilo" do treinador — não é bom nem mau, é só a personalidade táctica/gestão).
// - Ficha idêntica à dos jogadores (.pm-retro-*, 3 separadores, números coloridos em vez de
//   barras), com histórico de clubes, nacionalidade, e vitórias/empates/derrotas/%vitórias — a
//   interface fica para uma fase seguinte (esta fase é só o modelo de dados).
// - O utilizador (gestor) também tem perfil com o mesmo tipo de stats — ver extensão de
//   ensureManagerCareer em 04-financas.js.
// - Nomes reais para 14 clubes específicos (fornecidos pelo utilizador, 2026-09-22), fictícios
//   (randomNameForCountry, mesmo padrão da Academia/plantéis) para todos os outros. Idade,
//   nacionalidade e stats são sempre gerados normalmente, mesmo para os 14 nomes reais — só o
//   nome é fixo.
// - Fase 1 (este ficheiro nesta fase): modelo de dados, geração e registo de resultados de
//   jogo. A influência gradual dos stats nas decisões da IA ("cultura desliza devagar" —
//   mentalidade, agressividade, mercado) e a ficha/interface ficam para fases seguintes.

// Stats de competência — tendem a reflectir a qualidade/experiência do treinador; sobem em
// média com a reputação do clube que o contratou (um clube grande atrai treinadores melhores),
// com alguma variação individual.
const TREINADOR_STATS_COMPETENCIA = [
  "reputacaoExperiencia",
  "faroScouting",
  "adaptabilidade",
  "motivacaoCarisma",
  "desenvolvimentoJovens",
];
// Stats de perfil — não são "bons" nem "maus", são o estilo próprio do treinador; distribuição
// em sino centrada em 10 (soma de dois seededRnd(0,10) independentes), independente da
// reputação do clube — um clube pequeno pode ter um treinador tão ofensivo ou agressivo como um
// grande.
const TREINADOR_STATS_PERFIL = [
  "ofensividade",
  "agressividade",
  "liberdadeCriativa",
  "prefSistema",
  "prefJuventude",
  "ambicaoNegocial",
  "prudenciaFinanceira",
];
const TREINADOR_STATS_KEYS = TREINADOR_STATS_COMPETENCIA.concat(TREINADOR_STATS_PERFIL);

const TREINADOR_STAT_LABEL = {
  reputacaoExperiencia: "Reputação/Experiência",
  faroScouting: "Faro de Scouting",
  adaptabilidade: "Adaptabilidade",
  motivacaoCarisma: "Motivação/Carisma",
  desenvolvimentoJovens: "Desenvolvimento de Jovens",
  ofensividade: "Ofensividade",
  agressividade: "Agressividade",
  liberdadeCriativa: "Liberdade Criativa",
  prefSistema: "Preferência de Sistema (3-1 ↔ 2-2)",
  prefJuventude: "Preferência Juventude ↔ Experiência",
  ambicaoNegocial: "Ambição Negocial",
  prudenciaFinanceira: "Prudência Financeira",
};

// 14 nomes reais fornecidos pelo utilizador (2026-09-22), mapeados para os ids reais dos clubes
// na base de dados (confirmados por leitura directa de database/database.js). Todos os outros
// clubes recebem um nome gerado normalmente (randomNameForCountry). Só o nome é fixo — idade,
// nacionalidade e stats continuam a ser gerados como para qualquer treinador.
const TREINADOR_REAL_NOMES = {
  benfica: "Edu Castro",
  sporting: "Edo Bosch",
  porto: "Paulo Freitas",
  barcelos: "Rui Neto",
  braga: "Jorge Silva",
  valongo: "Raúl Meca",
  oliveirense: "Nuno Resende",
  tomar: "Nuno Lopes",
  ribadave: "Hugo Azevedo",
  pacense: "Paulo Pereira",
  sanjoanense: "Reinaldo Ventura",
  viana: "Renato Garrido",
  oeiras: "Pedro Nunes",
  candelaria: "João Miguel Santos",
};

// Mandato em curso — contador persistente de jogos/vitórias/empates/derrotas, incrementado jogo
// a jogo (ver registerTreinadorMatchResult). Corrige, de caminho, um bug pré-existente no CV do
// gestor: registerManagerClubExit lia estes números de careerSnapshot, que só reflecte a época
// ACTUAL (fixtures e team.stats são recriados todas as épocas) — qualquer mandato com mais de
// uma época acumulava sempre errado. mandatoAtual passa a ser a fonte de verdade para ambos.
function defaultTreinadorMandato(season, date) {
  return {
    epocaInicio: Number.isFinite(season) ? season : (state.season || 1),
    dataInicio: date ? isoDate(date instanceof Date ? date : new Date(date)) : null,
    jogos: 0,
    vitorias: 0,
    empates: 0,
    derrotas: 0,
  };
}

// Nível de partida das stats de competência — sobe com a reputação do clube (0-100), mapeado
// para uma banda 4-16 da escala 0-20, com uma pequena variação individual por stat.
function treinadorCompetenciaBase(team) {
  const rep = team && Number.isFinite(team.reputacao) ? team.reputacao : 50;
  return 4 + (rep / 100) * 12;
}
// Distribuição em sino 0-20, centrada em 10 — mesma técnica anti-saturação já usada para
// academyPotentialGap (soma de dois seededRnd(0,10) independentes em vez de um único
// seededRnd(0,20), que satura demasiado nos extremos).
function treinadorPerfilRoll(rng) {
  return seededRnd(rng, 0, 10) + seededRnd(rng, 0, 10);
}

function generateTreinadorStats(team, rng) {
  const stats = {};
  const base = treinadorCompetenciaBase(team);
  TREINADOR_STATS_COMPETENCIA.forEach(key => {
    stats[key] = clampAttr(base + seededRnd(rng, -3, 3));
  });
  TREINADOR_STATS_PERFIL.forEach(key => {
    stats[key] = clampAttr(treinadorPerfilRoll(rng));
  });
  return stats;
}

// Gera um treinador para um clube elegível. Determinístico (makeSeededRng por id do treinador),
// tal como o resto da geração de plantéis/academia do jogo — nada de Math.random() directo.
function generateTreinador(team) {
  const pais = normalizeCountryCode(teamCountry(team));
  const id = `${team.id}-treinador-${uid()}`;
  const rng = makeSeededRng(id);
  const nome = TREINADOR_REAL_NOMES[team.id] || randomNameForCountry(pais, rng);
  const idade = seededRnd(rng, 36, 64);
  const dataNascimento = makeBirthDate(rng, idade, state.currentDate ? new Date(state.currentDate) : undefined);
  return {
    id,
    nome,
    dataNascimento,
    nacionalidade: nationalityForCountry(pais),
    paisOrigem: pais,
    stats: generateTreinadorStats(team, rng),
    clubeActualId: team.id,
    mandatoAtual: defaultTreinadorMandato(state.season, state.currentDate),
    // Histórico de mandatos já terminados (mesma forma do g.historico do gestor humano) —
    // preenchido quando/se, numa fase futura, os treinadores da IA passarem a poder mudar de
    // clube; vazio para já (decisão do utilizador: treinadores da IA estáticos nesta 1ª fase).
    historico: [],
  };
}

// Mesma elegibilidade da Academia (academyEligible, 08b-academia-juvenis.js): nunca equipas B,
// nunca 3ª divisão, nunca clubes "nuvem" europeia — reaproveitada tal e qual, sem duplicar a
// regra.
function bootstrapTreinadorIfEmpty(team) {
  if (!academyEligible(team)) return;
  if (team.treinador) return;
  // Mercado de treinadores (2026-09-23): team.treinador===null passou a poder significar "vaga em
  // aberto" (despedimento/saída voluntária ainda por preencher — ver fireTreinador/
  // hireTreinadorForVacancy), não só "nunca teve treinador". Sem esta verificação, todo load de
  // gravação (normalizeLoadedTeams chama esta função incondicionalmente) recriava um treinador
  // novo do zero para qualquer clube que estivesse legitimamente vago, apagando a vaga em curso.
  if (team.treinadorVacancia) return;
  team.treinador = generateTreinador(team);
}

// Ponto único de registo de resultados (chamado de dentro de applyStandings, 06-motor-jogo.js,
// para AMBOS os clubes de qualquer jogo — liga, taça ou playoff). Incrementa o mandato em curso
// do treinador do clube e, quando o clube é o do utilizador, o mandato em curso do próprio
// gestor humano (ver ensureManagerCareer, 04-financas.js).
function registerTreinadorMatchResult(team, resultado) {
  if (!team) return;
  if (team.treinador) {
    if (!team.treinador.mandatoAtual) team.treinador.mandatoAtual = defaultTreinadorMandato(state.season, state.currentDate);
    const m = team.treinador.mandatoAtual;
    m.jogos++;
    if (resultado === "V") m.vitorias++;
    else if (resultado === "E") m.empates++;
    else if (resultado === "D") m.derrotas++;
  }
  if (team.id === state.userTeamId) {
    const g = ensureManagerCareer();
    if (!g.mandatoAtual) g.mandatoAtual = defaultTreinadorMandato(g.epocaInicioClube, g.dataInicioClube);
    const m = g.mandatoAtual;
    m.jogos++;
    if (resultado === "V") m.vitorias++;
    else if (resultado === "E") m.empates++;
    else if (resultado === "D") m.derrotas++;
  }
  // Mercado de treinadores (2026-09-23): barómetro contínuo de confiança da direção, generalizado
  // a TODOS os clubes (antes só corria para o do utilizador, ver updateDirectionConfidenceAfterMatch
  // em 04-financas.js) — alimenta o gatilho de despedimento por falta de confiança (ver
  // processTreinadorConfiancaMonthly, mais abaixo).
  updateDirectionConfidenceAfterMatch(team, resultado);
}

// ---------------------------------------------------------------------------------------------
// Fase 2 (2026-09-22) — Influência gradual do staff nas decisões do clube. Pedido do utilizador:
// "Os stats dos treinadores têm de algum modo influenciar as decisões do clube, se compram este
// ou aquele jogador, se jogam mais ofensivo ou menos, se jogam mais agressivo, se dá espaço à
// criatividade [...] Isto tem de vir de stats e são coisas que influenciam em médio prazo. Uma
// equipa não muda de um dia para o outro."
//
// Duas peças:
// 1. activeCoachingStats(team) — decide DE QUEM são as stats que comandam um clube: o próprio
//    gestor humano (state.gestor.stats) no clube do utilizador — dá um efeito real ao perfil que
//    o utilizador ganhou na Fase 1, para além de decorativo no CV — ou o treinador da IA em
//    qualquer outro clube. O treinador gerado para o clube do utilizador (bootstrapTreinadorIfEmpty
//    continua a criá-lo, por uniformidade de dados/futuras contratações) fica sem efeito nas
//    decisões desse clube — quem manda ali é o utilizador, tal como no resto do jogo.
// 2. team.treinadorCultura — três valores 0-20 (ofensividade/agressividade/liberdadeCriativa) que
//    NUNCA saltam para o perfil do treinador de imediato: deslizam 12%/mês na direcção dele (ver
//    processTreinadorCulturaMonthly, chamado a par de processAcademyMonthlyDevelopment em
//    09-fluxo-epoca.js). Um clube sem treinador nem gestor (equipas B, 3ª divisão, nuvem) fica
//    sempre em neutro (10/10/10, ver treinadorCulturaOrNeutral) — nunca chega a ter cultura própria.
function defaultTreinadorCultura() {
  return { ofensividade: 10, agressividade: 10, liberdadeCriativa: 10, lastMonthKey: null };
}
function treinadorCulturaOrNeutral(team) {
  return (team && team.treinadorCultura) || { ofensividade: 10, agressividade: 10, liberdadeCriativa: 10 };
}
function activeCoachingStats(team) {
  if (!team) return null;
  if (team.id === state.userTeamId) return ensureManagerCareer().stats;
  return team.treinador ? team.treinador.stats : null;
}
function processTreinadorCulturaMonthly(date) {
  const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
  Object.values(state.teams).forEach(team => {
    const stats = activeCoachingStats(team);
    if (!stats) return;
    if (!team.treinadorCultura) team.treinadorCultura = defaultTreinadorCultura();
    const c = team.treinadorCultura;
    if (c.lastMonthKey === monthKey) return;
    ["ofensividade", "agressividade", "liberdadeCriativa"].forEach(key => {
      c[key] = c[key] + (stats[key] - c[key]) * 0.12;
    });
    c.lastMonthKey = monthKey;
  });
}
// Modificador pequeno e limitado (±5%) ao ataque de teamStrength (06-motor-jogo.js) — "dar
// espaço à criatividade" na prática: mais liberdade criativa dá um ligeiro ganho ofensivo. A
// amplitude é deliberadamente pequena para não desequilibrar a calibração já existente do motor
// de jogo (finanças/golos foram calibrados sem este factor).
function creativeFreedomFactor(team) {
  const lc = treinadorCulturaOrNeutral(team).liberdadeCriativa;
  return clamp(1 + (lc - 10) * 0.0025, 0.95, 1.05);
}

// ---------------------------------------------------------------------------------------------
// Fase 3 (2026-09-22) — Ficha do staff, idêntica à do jogador. Pedido do utilizador: "A ficha dos
// treinadores deve ser idêntica à dos jogadores, com histórico de clubes. Nacionalidade. Vitórias
// empates derrotas %vitorias. O utilizador também tem perfil com stats."
//
// treinadorFichaData(kind, teamId) é o único adaptador de dados — devolve sempre a mesma forma,
// quer a ficha seja de um treinador da IA ("treinador") quer seja a do próprio gestor humano
// ("gestor") — para os dois abrirem exactamente o mesmo componente visual
// (renderTreinadorModalContent, 05-ui-navegacao.js), sem duplicar HTML/CSS.
function treinadorRecordPct(mandato) {
  if (!mandato || !mandato.jogos) return 0;
  return Math.round((mandato.vitorias / mandato.jogos) * 1000) / 10;
}
function treinadorFichaData(kind, teamId) {
  if (kind === "gestor") {
    const g = ensureManagerCareer();
    const team = state.teams[teamId] || state.teams[state.userTeamId] || null;
    return {
      kind: "gestor",
      teamId: team ? team.id : null,
      nome: state.managerName || "Treinador",
      nacionalidade: g.nacionalidade,
      dataNascimento: g.dataNascimento,
      stats: g.stats,
      clubeNome: team ? team.name : "Sem clube",
      mandatoAtual: g.mandatoAtual || defaultTreinadorMandato(g.epocaInicioClube, g.dataInicioClube),
      historico: g.historico || [],
    };
  }
  const team = state.teams[teamId];
  const tr = team && team.treinador;
  if (!tr) return null;
  return {
    kind: "treinador",
    teamId,
    nome: tr.nome,
    nacionalidade: tr.nacionalidade,
    dataNascimento: tr.dataNascimento,
    stats: tr.stats,
    clubeNome: team.name,
    mandatoAtual: tr.mandatoAtual || defaultTreinadorMandato(state.season, state.currentDate),
    historico: tr.historico || [],
    salario: tr.salario != null ? tr.salario : treinadorSalarioMensal(tr.stats, team),
  };
}

// ---------------------------------------------------------------------------------------------
// Fase 4 (2026-09-23) — Mercado de Treinadores. Pedido do utilizador: "Agora queria implementar o
// mercado de treinadores. Muito menos dinâmico, muito raro haver despedimentos durante a época. O
// clube fica sem treinador, deve ser possível concorrer ao lugar. Não deve ser possível ao
// utilizador concorrer a clubes com treinador. Não há compras de treinadores, só contrato. O
// despedimento deve ser um recurso apenas quando a confiança da direção está baixa durante algum
// tempo. A direção faz avisos primeiro. Sempre que há despedimentos a contratações de treinadores
// na divisão do clube do utilizador, são uma notícia. Um clube pode abordar treinadores de
// outros. Entra a reputação e o salário."
//
// Decisões de âmbito (para manter o sistema pequeno e coerente com o resto do jogo):
// - Aplica-se só a treinadores da IA (team.id!==state.userTeamId). A segurança no cargo do
//   PRÓPRIO utilizador já tem um sistema completo e independente (checkManagerSacking, secção
//   "Carreira do treinador" acima) — não é tocado aqui.
// - "Só contrato, sem compras": não existe nenhum equivalente a uma taxa de transferência — uma
//   contratação é sempre só a atribuição de um treinador (livre ou "abordado" a outro clube) ao
//   clube com vaga, nunca uma negociação de fee entre clubes.
// - Salário: os treinadores da IA passam a ter um `salario` (mensal, cosmético — não é lançado
//   nas finanças do clube nesta fase, à semelhança de academy.monthlyCost/reputation na Fase 1 da
//   Academia) que entra, a par da reputação, na pontuação de compatibilidade clube-treinador
//   (treinadorFitScore) — um clube pequeno prefere um treinador mais barato/menos exigente, um
//   clube grande tolera (e prefere) um treinador mais caro e mais reputado.
function treinadorSalarioMensal(stats, team) {
  const rep = stats && Number.isFinite(stats.reputacaoExperiencia) ? stats.reputacaoExperiencia : 10;
  const ambicao = stats && Number.isFinite(stats.ambicaoNegocial) ? stats.ambicaoNegocial : 10;
  const base = 800 + rep * 180 + Math.max(0, ambicao - 10) * 120;
  return Math.round(base / 50) * 50;
}
// Backfill idempotente (saves anteriores a esta fase não têm salario/contadores de segurança no
// cargo) — mesmo padrão de normalização-ao-acesso já usado em ensureManagerCareer/
// ensureTeamDirecaoInvestimentos (04-financas.js).
function ensureTreinadorSeguranca(team) {
  if (team.treinadorConfiancaBaixaMeses == null) team.treinadorConfiancaBaixaMeses = 0;
  if (team.treinadorAvisoEmitido == null) team.treinadorAvisoEmitido = false;
  if (team.treinador && team.treinador.salario == null) team.treinador.salario = treinadorSalarioMensal(team.treinador.stats, team);
  return team;
}
// Limiares do gatilho de despedimento — deliberadamente exigentes para ser "muito raro": a
// confiança começa em 60 e move-se no máximo ±4/±3 por jogo (updateDirectionConfidenceAfterMatch),
// por isso só uma época genuinamente desastrosa e sustentada a empurra, e mantém, abaixo de 25.
const TREINADOR_CONFIANCA_LIMIAR = 25;
const TREINADOR_MESES_ATE_AVISO = 3;
const TREINADOR_MESES_ATE_DESPEDIMENTO_APOS_AVISO = 2;
// Período de proteção — um treinador recém-chegado (ou recém-promovido a partir da 3ª divisão,
// via bootstrapTreinadorIfEmpty) nunca é despedido por uma crise de confiança herdada.
const TREINADOR_MESES_MANDATO_PROTEGIDO = 6;
function treinadorMesesDeMandato(team, date) {
  const inicio = team.treinador && team.treinador.mandatoAtual && team.treinador.mandatoAtual.dataInicio;
  if (!inicio) return 999;
  return Math.max(0, Math.round((new Date(date) - new Date(inicio)) / 2629800000));
}
// Único ponto de registo de uma saída de treinador (despedimento OU saída voluntária por
// abordagem de outro clube) — mesma forma do historico já usado por registerManagerClubExit
// (gestor humano), para os dois tipos de CV terem sempre a mesma estrutura.
function registerTreinadorClubExit(tr, team, date, motivo) {
  const m = tr.mandatoAtual || { jogos: 0, vitorias: 0, empates: 0, derrotas: 0 };
  tr.historico = Array.isArray(tr.historico) ? tr.historico : [];
  tr.historico.unshift({ clubId: team.id, clubName: team.name, epocaSaida: seasonLabel(state.season), jogos: m.jogos, vitorias: m.vitorias, empates: m.empates, derrotas: m.derrotas, motivoSaida: motivo, data: isoDate(date) });
  if (tr.historico.length > 10) tr.historico.length = 10;
  tr.clubeActualId = null;
  tr.mandatoAtual = null;
}
// Notícia de mercado de treinadores — só para despedimentos/contratações (não para os avisos da
// direção, que ficam internos), e só quando o clube envolvido está na MESMA divisão do clube do
// utilizador (pedido explícito do utilizador) — verificação directa por divisaoAtual, mais
// robusta do que o filtro de texto já usado para kind:"mercado" (newsIsFromUserDivision).
function pushTreinadorMercadoNews(team, date, text, title) {
  const mine = myTeam();
  if (!mine || team.divisaoAtual !== mine.divisaoAtual) return;
  pushNews(date, text, "staff", title, { teamId: team.id });
}
// Despedimento — recurso raro, só depois do aviso formal da direção (ver
// processTreinadorConfiancaMonthly). Abre uma vaga (team.treinador=null) em vez de substituir de
// imediato — é essa vaga que fica disponível para o utilizador concorrer (managerVacantEligibleClubs)
// e que resolvePendingTreinadorVacancies preenche pela IA ao fim de algumas semanas, se ninguém a
// ocupar antes.
function fireTreinador(team, date, motivo) {
  const tr = team.treinador;
  if (!tr) return;
  registerTreinadorClubExit(tr, team, date, motivo || "resultados");
  state.treinadoresDisponiveis.unshift(tr);
  if (state.treinadoresDisponiveis.length > 25) state.treinadoresDisponiveis.length = 25;
  team.treinador = null;
  const rng = makeSeededRng(`treinador-vaga:${team.id}:${isoDate(date)}`);
  team.treinadorVacancia = { desde: isoDate(date), motivo: motivo || "resultados", resolverEm: isoDate(addDays(date, seededRnd(rng, 14, 28))) };
  team.treinadorConfiancaBaixaMeses = 0;
  team.treinadorAvisoEmitido = false;
  // Novo ciclo para a direção, sem herdar a crise que já custou o lugar ao treinador anterior.
  team.confiancaDirecao = Math.max(team.confiancaDirecao || 60, 45);
  pushTreinadorMercadoNews(team, date, `A direção do ${teamLinkHtml(team.id)} anunciou o fim do vínculo com o treinador ${escapeHtml(tr.nome)} — resultados desportivos muito abaixo do exigido, depois de vários avisos.`, "Despedimento de treinador");
}
// Gatilho mensal — auto-guardado por clube (treinadorConfiancaMonthKey), tal como
// processTreinadorCulturaMonthly/academy.lastMonthKey. Só clubes de IA elegíveis e já com
// treinador (uma vaga em aberto não tem confiança para monitorizar — está já a ser preenchida por
// resolvePendingTreinadorVacancies).
function processTreinadorConfiancaMonthly(date) {
  const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
  Object.values(state.teams).forEach(team => {
    if (team.id === state.userTeamId) return;
    if (!academyEligible(team) || !team.treinador) return;
    ensureTreinadorSeguranca(team);
    if (team.treinadorConfiancaMonthKey === monthKey) return;
    team.treinadorConfiancaMonthKey = monthKey;
    if (team.confiancaDirecao == null) team.confiancaDirecao = 60;
    // Período de proteção verificado ANTES de contar meses de crise (não só antes de despedir) —
    // senão a contagem avançava "em segredo" durante a lua-de-mel e um treinador recém-chegado
    // ficava logo vulnerável mal a proteção acabasse, o que anulava o próprio objetivo dela.
    if (treinadorMesesDeMandato(team, date) < TREINADOR_MESES_MANDATO_PROTEGIDO) {
      team.treinadorConfiancaBaixaMeses = 0;
      team.treinadorAvisoEmitido = false;
      return;
    }
    if (team.confiancaDirecao < TREINADOR_CONFIANCA_LIMIAR) {
      team.treinadorConfiancaBaixaMeses++;
    } else {
      team.treinadorConfiancaBaixaMeses = 0;
      team.treinadorAvisoEmitido = false;
      return;
    }
    if (!team.treinadorAvisoEmitido && team.treinadorConfiancaBaixaMeses >= TREINADOR_MESES_ATE_AVISO) {
      // Aviso formal da direção — fica só como estado interno (não gera notícia; só
      // despedimentos/contratações geram, pedido explícito do utilizador), mas é o que faz o
      // despedimento nunca ser instantâneo.
      team.treinadorAvisoEmitido = true;
    } else if (team.treinadorAvisoEmitido && team.treinadorConfiancaBaixaMeses >= TREINADOR_MESES_ATE_AVISO + TREINADOR_MESES_ATE_DESPEDIMENTO_APOS_AVISO) {
      fireTreinador(team, date, "resultados");
    }
  });
}
// Candidatos a preencher uma vaga por "abordagem" a um treinador já empregado noutro clube
// (pedido do utilizador: "um clube pode abordar treinadores de outros") — só de cima para baixo
// (o clube com a vaga tem de ter claramente mais reputação do que o clube de origem) e nunca a um
// clube que esteja ele próprio com uma vaga em aberto.
function treinadorPoachCandidates(team) {
  return Object.values(state.teams).filter(other =>
    other.id !== team.id && other.id !== state.userTeamId &&
    academyEligible(other) && other.treinador && !other.treinadorVacancia &&
    team.reputacao > (other.reputacao || 0) + 15
  );
}
// Pontuação de compatibilidade clube-treinador — entra a reputação (quanto mais perto da banda de
// reputação do clube, melhor) e o salário (um clube de reputação mais baixa penaliza mais um
// treinador caro, um clube grande tolera-o e até o prefere) — pedido explícito do utilizador:
// "Entra a reputação e o salário."
function treinadorFitScore(tr, team) {
  const repAlvo = (team.reputacao || 50) / 5; // reputação do clube (0-100) mapeada para a escala 0-20 das stats
  const repGap = -Math.abs((tr.stats.reputacaoExperiencia || 0) - repAlvo);
  const toleranciaSalarial = (team.reputacao || 50) >= 60 ? 0.5 : 1.4;
  const custoPenal = -((tr.salario != null ? tr.salario : treinadorSalarioMensal(tr.stats, team)) / 1000) * toleranciaSalarial;
  return repGap + custoPenal;
}
// Preenche uma vaga — nunca por "compra" (pedido do utilizador), só por contrato: ou reaproveita
// um treinador disponível (despedido de outro clube), ou "aborda" um treinador já empregado num
// clube claramente menor (deixando esse clube com uma vaga nova, em cadeia), ou, na ausência de
// qualquer candidato adequado, gera um treinador novo (mesma geração da Fase 1).
function hireTreinadorForVacancy(team, date) {
  const rng = makeSeededRng(`treinador-contratacao:${team.id}:${isoDate(date)}`);
  // 2026-10-16: nunca o treinador que este mesmo clube acabou de despedir (no 1.º despedimento da
  // carreira era o único disponível e o clube "contratava-o" de volta semanas depois).
  const candidatos = state.treinadoresDisponiveis.filter(tr => !(tr.historico && tr.historico[0] && tr.historico[0].clubId === team.id)).map(tr => ({ tr, score: treinadorFitScore(tr, team), origemClube: null }));
  // Probabilidade pequena de considerar também abordagem a treinadores já empregados — mantém a
  // "abordagem" como algo ocasional, não a via normal de preenchimento de vagas.
  if (seededRndFloat(rng, 0, 1) < 0.3) {
    treinadorPoachCandidates(team).forEach(other => {
      candidatos.push({ tr: other.treinador, score: treinadorFitScore(other.treinador, team) + 2, origemClube: other });
    });
  }
  candidatos.sort((a, b) => b.score - a.score);
  const escolha = candidatos[0];
  if (escolha) {
    const tr = escolha.tr;
    if (escolha.origemClube) {
      const origem = escolha.origemClube;
      registerTreinadorClubExit(tr, origem, date, "saida-voluntaria");
      origem.treinador = null;
      const rngOrigem = makeSeededRng(`treinador-vaga:${origem.id}:${isoDate(date)}`);
      origem.treinadorVacancia = { desde: isoDate(date), motivo: "saida-voluntaria", resolverEm: isoDate(addDays(date, seededRnd(rngOrigem, 14, 28))) };
      origem.treinadorConfiancaBaixaMeses = 0;
      origem.treinadorAvisoEmitido = false;
      pushTreinadorMercadoNews(origem, date, `${escapeHtml(tr.nome)} deixou o ${teamLinkHtml(origem.id)} para assumir o comando técnico de outro clube.`, "Saída de treinador");
    } else {
      state.treinadoresDisponiveis = state.treinadoresDisponiveis.filter(t => t !== tr);
    }
    tr.clubeActualId = team.id;
    tr.mandatoAtual = defaultTreinadorMandato(state.season, date);
    team.treinador = tr;
  } else {
    team.treinador = generateTreinador(team);
  }
  team.treinadorVacancia = null;
  team.confiancaDirecao = Math.max(team.confiancaDirecao || 60, 55);
  pushTreinadorMercadoNews(team, date, `O ${teamLinkHtml(team.id)} anunciou a contratação de ${escapeHtml(team.treinador.nome)} como novo treinador principal.`, "Novo treinador");
}
// Desvantagem de jogar sem treinador (2026-09-23, pedido explícito do utilizador: "Um clube sem
// treinador tem de ter alguma desvantagem") — enquanto a vaga estiver em aberto, a equipa é
// gerida por um interino: pequena penalização ao rendimento em jogo (ataque E defesa), aplicada
// em teamStrength/onRinkStrength (06-motor-jogo.js) no mesmo espírito e amplitude de
// creativeFreedomFactor (Fase 2) — deliberadamente pequena para não desequilibrar a calibração já
// existente do motor de jogo, mas suficiente para se notar e para dar um incentivo real a
// resolver a vaga depressa (candidatura do utilizador, ou a IA preenchê-la sozinha).
function treinadorVacanciaPenaltyFactor(team) {
  return (team && team.treinadorVacancia) ? 0.93 : 1;
}
// Ponto único diário (chamado de dentro de dailyConditionRecovery, 09-fluxo-epoca.js, a par de
// resolvePendingManagerCareerEvents) — só resolve vagas de clubes de IA; a vaga do próprio clube
// do utilizador não existe (ver âmbito no topo desta secção).
function resolvePendingTreinadorVacancies(date) {
  Object.values(state.teams).forEach(team => {
    if (team.id === state.userTeamId) return;
    if (!team.treinadorVacancia) return;
    if (new Date(date) < new Date(team.treinadorVacancia.resolverEm)) return;
    hireTreinadorForVacancy(team, date);
  });
}
// Lista de clubes a que o UTILIZADOR se pode candidatar (secção "Candidatar-me a outro clube" da
// Carreira do treinador) — managerEligibleClubs() (04-financas.js) continua, sem alterações, a
// servir as PROPOSTAS que outros clubes fazem ao utilizador (maybeGenerateManagerJobOffers — a
// abordagem/assédio a um treinador já empregado não depende de vaga, é o mesmo mecanismo de
// treinadorPoachCandidates acima, só que do lado humano). Mas a iniciativa INVERSA — o utilizador
// candidatar-se — só pode visar clubes sem treinador (pedido explícito: "Não deve ser possível ao
// utilizador concorrer a clubes com treinador").
function managerVacantEligibleClubs() {
  return managerEligibleClubs().filter(t => !t.treinador);
}

// ---------------------------------------------------------------------------------------------
// Selecção Nacional — Acumulação de Cargo (2026-10-03, pedido do utilizador: "Quero poder ser
// convidado para assumir uma selecção nacional e acumular o cargo"). Decisões confirmadas com o
// utilizador (AskUserQuestion):
// - Só 5 nações alguma vez convidam o utilizador — "As de Portugal, Itália, Espanha, Argentina e
//   França" (SELECAO_SELECIONAVEIS abaixo). Nenhuma selecção, destas ou das outras 7 cobertas por
//   07h-selecoes.js, tem um "seleccionador de IA" — o cargo fica simplesmente por preencher até
//   ser atribuído ao utilizador. Não existe mercado de seleccionadores (ao contrário do Mercado de
//   Treinadores de clube, Fase 4 acima) — manter isto pequeno foi decisão deliberada, para não
//   duplicar toda a máquina de fitScore/poaching só para 5 equipas que nunca jogam fora de uma
//   janela de ~6 dias por época.
// - "Eu faço a convocatória": quando o utilizador é seleccionador, É ELE que escolhe a convocatória
//   à mão (ver o desvio em prepareSelecoesEdicaoForNewSeason e o novo modal
//   #selecaoConvocatoriaManualModal, 07h-selecoes.js/09-fluxo-epoca.js) — nunca o algoritmo
//   automático (pickNationalSquad) para a nação que ele comanda.
// - "Sim, com risco": a federação pode despedi-lo por maus resultados, independentemente do seu
//   cargo no clube — ver processSelecaoParticipationOutcome mais abaixo, chamado por
//   07h-selecoes.js no fecho de cada edição em que a nação do utilizador participou. Nunca mexe no
//   mandato de clube (g.mandatoAtual/g.historico), que é tratado à parte (04-financas.js).
const SELECAO_SELECIONAVEIS = ["pt", "it", "es", "ar", "fr"];
// Limiares de elegibilidade para um convite — deliberadamente exigentes (só um gestor já com
// currículo feito no clube chega lá), mesmo espírito dos limiares "muito raro" do despedimento de
// treinadores de clube acima.
const SELECAO_INVITE_REP_MIN = 60;
const SELECAO_INVITE_EXPERIENCIA_MIN = 10;
const SELECAO_INVITE_CHANCE = 0.15;
const SELECAO_INVITE_COOLDOWN_SEASONS = 2;
// Limiar de confiança da federação abaixo do qual uma participação conta como "crise" — duas
// participações seguidas abaixo disto custam o cargo (ver processSelecaoParticipationOutcome).
const SELECAO_CONFIANCA_LIMIAR = 25;

function selecaoNomeDaNacao(code) {
  const n = (typeof SELECAO_NATIONS !== "undefined" ? SELECAO_NATIONS : null) && SELECAO_NATIONS[code];
  return n ? n.nome : code;
}

// Convites pendentes/recebidos (mesma forma de g.ofertas, 04-financas.js) — avaliados uma vez por
// época, a par de maybeGenerateManagerJobOffers (ver processManagerCareerSeasonEnd, 04-financas.js).
function maybeGenerateSelecaoInvites(date) {
  const g = ensureManagerCareer();
  if (g.selecaoAtual) return; // só um cargo de selecção de cada vez
  const rng = makeSeededRng(`selecao-convites:${isoDate(date)}`);
  SELECAO_SELECIONAVEIS.forEach(code => {
    if (g.convitesSelecao.some(c => c.code === code && c.estado === "pendente")) return;
    // Período de nódoa (2 épocas) depois de uma saída (despedimento OU demissão) dessa MESMA
    // nação — evita um convite imediato a seguir a sair de lá.
    const ultimaSaida = (g.selecaoHistorico || []).find(h => h.code === code);
    if (ultimaSaida && Number.isFinite(ultimaSaida.epocaSaida)) {
      if ((state.season || 0) - ultimaSaida.epocaSaida < SELECAO_INVITE_COOLDOWN_SEASONS) return;
    }
    if (g.reputacao < SELECAO_INVITE_REP_MIN) return;
    if ((g.stats.reputacaoExperiencia || 0) < SELECAO_INVITE_EXPERIENCIA_MIN) return;
    if (seededRndFloat(rng, 0, 1) > SELECAO_INVITE_CHANCE) return;
    const convite = { id: `${code}:${isoDate(date)}`, code, nome: selecaoNomeDaNacao(code), dataOferta: isoDate(date), expiraEm: isoDate(addDays(date, 21)), estado: "pendente" };
    g.convitesSelecao.unshift(convite);
    if (g.convitesSelecao.length > 20) g.convitesSelecao = g.convitesSelecao.slice(0, 20);
    pushNews(date, `A federação de ${selecaoNomeDaNacao(code)} contactou-te com um convite para assumires o comando técnico da selecção nacional, em acumulação com o teu clube.`, "gestor", "Convite de selecção nacional", { autoAdvanceStop: true });
  });
}

function respondToSelecaoInvite(inviteId, accept, date) {
  const g = ensureManagerCareer();
  const c = g.convitesSelecao.find(x => x.id === inviteId && x.estado === "pendente");
  if (!c) return { outcome: "recusa", reason: "Convite não encontrado ou já respondido." };
  if (new Date(date) > new Date(c.expiraEm)) { c.estado = "expirada"; return { outcome: "recusa", reason: "Este convite já expirou." }; }
  if (!accept) { c.estado = "recusado-pelo-utilizador"; return { outcome: "recusada" }; }
  if (g.selecaoAtual) return { outcome: "recusa", reason: "Já estás à frente de outra selecção nacional." };
  c.estado = "aceite";
  g.selecaoAtual = { code: c.code, desde: isoDate(date), confiancaFederacao: 60, participacoes: [] };
  g.convitesSelecao.forEach(o => { if (o.estado === "pendente" && o.id !== c.id) o.estado = "cancelada"; });
  pushNews(date, `Assumiste o comando técnico da Selecção de ${selecaoNomeDaNacao(c.code)}, em acumulação com o teu cargo no clube.`, "gestor", "Novo cargo: selecção nacional", { autoAdvanceStop: true });
  return { outcome: "aceite" };
}

// Único ponto de registo de uma saída da selecção (despedimento OU demissão voluntária) — mesma
// forma do historico de clube (registerManagerClubExit, 04-financas.js), para os dois tipos de CV
// terem sempre uma estrutura parecida.
function registerSelecaoExit(g, date, motivo) {
  const s = g.selecaoAtual;
  if (!s) return;
  g.selecaoHistorico = Array.isArray(g.selecaoHistorico) ? g.selecaoHistorico : [];
  g.selecaoHistorico.unshift({ code: s.code, nome: selecaoNomeDaNacao(s.code), desde: s.desde, ate: isoDate(date), epocaSaida: state.season, motivoSaida: motivo, participacoes: s.participacoes || [] });
  if (g.selecaoHistorico.length > 20) g.selecaoHistorico.length = 20;
  g.selecaoAtual = null;
}

function resignFromSelecao(date) {
  const g = ensureManagerCareer();
  if (!g.selecaoAtual) return { outcome: "recusa", reason: "Não estás actualmente à frente de nenhuma selecção nacional." };
  const nome = selecaoNomeDaNacao(g.selecaoAtual.code);
  registerSelecaoExit(g, date, "demissao");
  pushNews(date, `Demitiste-te do cargo de seleccionador de ${nome} — o teu cargo no clube não é afectado.`, "gestor", "Demissão da selecção", { autoAdvanceStop: true });
  return { outcome: "demissao" };
}

// Chamado por 07h-selecoes.js (processSelecoesForCurrentDate) quando uma edição termina e a nação
// do utilizador participou nela. placementIndex vem de finalRanking: 0=campeão, 1=finalista,
// 2=3º lugar, 3=4º lugar, 4-7=eliminado nos quartos. Delta de confiança no mesmo espírito de
// updateManagerReputationAfterSeason (04-financas.js) — mas por PARTICIPAÇÃO, não por época,
// porque nem todas as nações jogam todas as épocas (ex. Argentina só entra nas edições do
// Mundial — ver SELECAO_MUNDIAL_ORDER, 07h-selecoes.js).
const SELECAO_RESULTADO_DELTA = { campeao: 12, finalista: 5, terceiro: -2, quartos: -8 };
function selecaoResultadoLabel(placementIndex) {
  if (placementIndex === 0) return "campeao";
  if (placementIndex === 1) return "finalista";
  if (placementIndex <= 3) return "terceiro"; // 3º ou 4º lugar — ambos "chegaram às meias"
  return "quartos";
}
function processSelecaoParticipationOutcome(code, season, prova, placementIndex) {
  const g = ensureManagerCareer();
  if (!g.selecaoAtual || g.selecaoAtual.code !== code) return;
  const resultado = selecaoResultadoLabel(placementIndex);
  const delta = SELECAO_RESULTADO_DELTA[resultado];
  g.selecaoAtual.confiancaFederacao = clamp((Number.isFinite(g.selecaoAtual.confiancaFederacao) ? g.selecaoAtual.confiancaFederacao : 60) + delta, 0, 100);
  g.selecaoAtual.participacoes = Array.isArray(g.selecaoAtual.participacoes) ? g.selecaoAtual.participacoes : [];
  g.selecaoAtual.participacoes.push({ season, prova, resultado, confiancaApos: g.selecaoAtual.confiancaFederacao });
  if (g.selecaoAtual.participacoes.length > 10) g.selecaoAtual.participacoes = g.selecaoAtual.participacoes.slice(-10);
  const ultimas = g.selecaoAtual.participacoes.slice(-2);
  if (ultimas.length === 2 && ultimas.every(p => p.confiancaApos < SELECAO_CONFIANCA_LIMIAR)) {
    const nome = selecaoNomeDaNacao(code);
    registerSelecaoExit(g, state.currentDate, "despedido");
    pushNews(state.currentDate, `A federação de ${nome} anunciou o fim do teu vínculo como seleccionador — resultados muito abaixo do exigido em participações sucessivas. O teu cargo no clube não é afectado.`, "gestor", "Despedido pela federação", { autoAdvanceStop: true });
  }
}

// Influência táctica da selecção do utilizador — reaproveita tal e qual o mesmo mecanismo já
// usado pelos clubes (treinadorCultura/chooseAiMentalidade/chooseAiSistema/creativeFreedomFactor,
// acima nesta secção e em 06-motor-jogo.js) sem NENHUMA alteração ao motor: newMatchState já lê
// treinadorCulturaOrNeutral(team) para decidir mentalidade/sistema de QUALQUER equipa, incluindo
// as virtuais das selecções — só nunca tinham este campo preenchido, por isso caíam sempre no
// neutro (10/10/10). Ao contrário da cultura de clube, aqui NÃO desliza 12%/mês: uma selecção
// reúne-se só por uma janela de ~6 dias por época, não faz sentido "assentar devagar" — o
// utilizador trouxe o seu próprio estilo já formado para esta convocatória.
function selecaoTreinadorCulturaFromGestor(g) {
  return { ofensividade: g.stats.ofensividade, agressividade: g.stats.agressividade, liberdadeCriativa: g.stats.liberdadeCriativa, lastMonthKey: null };
}
